// ══════════════════════════════════════════════════════════════════════
// MATERIAL PAGE OVERRIDES v2 — loaded ONLY by material.html, after every
// shared js/*.js module. Redefines specific render functions in place
// (last declaration wins in global scope) so index.html and the shared
// js/ files that power your production app are never modified.
//
// Needs one Supabase table to unlock the System Log + device-sharing
// features — see the SQL block at the very bottom of this file. Until
// that table exists, everything else here still works fine; the System
// Log page will just show a "run setup" message instead of data.
// ══════════════════════════════════════════════════════════════════════

// ── Version badge — informational only, not a link ──────────────────────
(function(){
  function killVersionBadgeClick(){
    const el=document.getElementById('sb-version-badge');
    if(!el)return;
    el.onclick=null; el.style.cursor='default'; el.removeAttribute('title');
  }
  killVersionBadgeClick();
  setTimeout(killVersionBadgeClick,1200);
  setTimeout(killVersionBadgeClick,3500);
})();

// ══════════════════════════════════════════════════════════════════════
// SHARED VISUAL HELPERS
// ══════════════════════════════════════════════════════════════════════
function deltaChip(curr,prev,invert){
  curr=curr||0; prev=prev||0;
  if(prev===0&&curr===0) return `<span style="display:inline-flex;align-items:center;gap:3px;font-size:11px;font-weight:700;color:var(--tx3);background:var(--s2);padding:2px 8px;border-radius:100px">— flat</span>`;
  let pct = prev===0 ? 100 : Math.round((curr-prev)/prev*100);
  const up = curr>prev, flat = curr===prev;
  const good = flat ? null : invert ? !up : up;
  const color = flat?'var(--tx3)':good?'#146C2E':'#B3261E';
  const bg = flat?'var(--s2)':good?'var(--gb)':'var(--rb)';
  const arrow = flat?'—':up?'▲':'▼';
  return `<span style="display:inline-flex;align-items:center;gap:3px;font-size:11px;font-weight:700;color:${color};background:${bg};padding:2px 9px;border-radius:100px;white-space:nowrap">${arrow} ${Math.abs(pct)}%</span>`;
}

// Records today's KPI values once per calendar day and hands back the most
// recent PRIOR day's values, so dashboard stat boxes can show a real
// day-over-day trend via deltaChip() without needing a server-side
// history table. Keeps 14 days, all in localStorage (per-browser, not
// synced across devices — fine for a glance-able trend indicator).
function dashSnapshot(values){
  const KEY='vas_kpi_hist';
  let hist={};
  try{ hist=JSON.parse(localStorage.getItem(KEY)||'{}'); }catch(e){}
  const today=localDateStr();
  const priorDate=Object.keys(hist).filter(d=>d<today).sort().pop();
  const prior=priorDate?hist[priorDate]:null;
  hist[today]={...(hist[today]||{}),...values};
  const allDates=Object.keys(hist).sort();
  if(allDates.length>14) allDates.slice(0,allDates.length-14).forEach(d=>delete hist[d]);
  try{ localStorage.setItem(KEY,JSON.stringify(hist)); }catch(e){}
  return prior; // {key:value,...} from the last day we had data, or null the first time
}
// dchip(): renders deltaChip only once we actually have a prior-day value to compare against
function dchip(prior,key,curr,invert){
  if(!prior||prior[key]===undefined||prior[key]===null) return '';
  return deltaChip(curr,prior[key],invert);
}

function icon(name,size=14){
  const paths={
    building:'<path d="M3 21V7l7-4v18M14 21V11l7 4v6"/><path d="M9 9h.01M9 13h.01M9 17h.01"/>',
    pin:'<path d="M12 21s-7-6.5-7-11a7 7 0 0 1 14 0c0 4.5-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    link:'<path d="M9 15l6-6"/><path d="M10 6l1-1a4 4 0 0 1 6 6l-1 1"/><path d="M14 18l-1 1a4 4 0 0 1-6-6l1-1"/>',
    list:'<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.01M3 12h.01M3 18h.01"/>',
    alert:'<path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/>',
    users:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    gauge:'<path d="M12 14 15 9"/><circle cx="12" cy="14" r="1.5"/><path d="M4 15a8 8 0 1 1 16 0"/>',
    shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  };
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;vertical-align:-2px">${paths[name]||''}</svg>`;
}

// Multi-series line chart, hand-rolled SVG (no external chart dependency)
function svgLineChart(categories,series){
  const W=560,H=190,padL=34,padB=22,padT=10,padR=8;
  const innerW=W-padL-padR, innerH=H-padT-padB;
  const maxV=Math.max(1,...series.flatMap(s=>s.data));
  const stepX=innerW/((categories.length-1)||1);
  const yFor=v=>padT+innerH-(v/maxV*innerH);
  const xFor=i=>padL+i*stepX;
  let grid='';
  const gridLines=4;
  for(let i=0;i<=gridLines;i++){
    const y=padT+innerH-(innerH/gridLines*i);
    const val=Math.round(maxV/gridLines*i);
    grid+=`<line x1="${padL}" y1="${y}" x2="${W-padR}" y2="${y}" stroke="var(--bd)" stroke-width="1"/><text x="${padL-6}" y="${y+3}" text-anchor="end" font-size="9" fill="var(--tx3)">${val}</text>`;
  }
  let paths='';
  series.forEach(s=>{
    const pts=s.data.map((v,i)=>`${xFor(i)},${yFor(v)}`).join(' ');
    paths+=`<polyline points="${pts}" fill="none" stroke="${s.color}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>`;
    paths+=s.data.map((v,i)=>`<circle cx="${xFor(i)}" cy="${yFor(v)}" r="3" fill="${s.color}"/>`).join('');
  });
  const labels=categories.map((c,i)=>`<text x="${xFor(i)}" y="${H-4}" text-anchor="middle" font-size="9" fill="var(--tx3)">${c}</text>`).join('');
  const legend=series.map(s=>`<span style="display:inline-flex;align-items:center;gap:5px;font-size:11px;color:var(--tx2);font-weight:600"><span style="width:10px;height:10px;border-radius:3px;background:${s.color};display:inline-block"></span>${s.label}</span>`).join('');
  return `<div><svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;display:block">${grid}${paths}${labels}</svg><div style="display:flex;gap:16px;margin-top:8px;flex-wrap:wrap">${legend}</div></div>`;
}

function svgHBar(items,opts={}){
  const max=Math.max(1,...items.map(i=>i.value));
  return items.map(i=>{
    const pct=Math.round(i.value/max*100);
    return `<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;cursor:${i.onclick?'pointer':'default'}" ${i.onclick?`onclick="${i.onclick}"`:''}>
      <div style="width:${opts.labelW||96}px;font-size:12px;color:var(--tx2);font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex-shrink:0">${i.label}</div>
      <div style="flex:1;height:10px;background:var(--s2);border-radius:100px;overflow:hidden"><div style="height:100%;width:${pct}%;background:${i.color};border-radius:100px;transition:width .5s"></div></div>
      <div style="width:26px;font-size:12px;font-weight:700;color:${i.color};text-align:right;flex-shrink:0">${i.value}</div>
    </div>`;
  }).join('')||`<div style="font-size:12px;color:var(--tx3);text-align:center;padding:14px 0">No data</div>`;
}

function svgDonutChart(data,size=108){
  const total=data.reduce((s,d)=>s+d.v,0);
  const r=size/2-10,cx=size/2,cy=size/2,c=2*Math.PI*r;
  let paths='',offset=0;
  if(total){
    data.forEach(d=>{
      if(!d.v)return;
      const pct=d.v/total,dash=Math.max(pct*c-2,0),gap=c-dash;
      paths+=`<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${d.color}" stroke-width="13" stroke-linecap="round" stroke-dasharray="${dash} ${gap}" stroke-dashoffset="${-(offset*c)}" transform="rotate(-90 ${cx} ${cy})" onclick="navTo('alltasks')" style="cursor:pointer"/>`;
      offset+=pct;
    });
  } else {
    paths=`<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="var(--bd)" stroke-width="13"/>`;
  }
  return `<div style="display:flex;align-items:center;gap:14px">
    <svg width="${size}" height="${size}" style="flex-shrink:0">${paths}<text x="${cx}" y="${cy-3}" text-anchor="middle" font-size="20" font-weight="800" fill="var(--tx)" font-family="var(--fn)">${total}</text><text x="${cx}" y="${cy+13}" text-anchor="middle" font-size="8.5" font-weight="700" fill="var(--tx3)" font-family="var(--fn)">ACTIVE</text></svg>
    <div style="flex:1;display:flex;flex-direction:column;gap:6px;min-width:0">
      ${data.map(d=>`<div onclick="navTo('alltasks')" style="display:flex;align-items:center;gap:7px;cursor:pointer">
        <span style="width:9px;height:9px;border-radius:3px;background:${d.color};flex-shrink:0"></span>
        <span style="font-size:11.5px;color:var(--tx2);font-weight:600;flex:1">${d.label}</span>
        <strong style="font-size:12.5px;color:${d.color}">${d.v}</strong>
      </div>`).join('')}
    </div>
  </div>`;
}

function riskGaugeArc(pct,color,label,sub){
  const r=48,cx=60,cy=58,totalLen=Math.PI*r;
  const dash=Math.max(0,Math.min(100,pct))/100*totalLen;
  return `<svg viewBox="0 0 120 66" style="width:100%;max-width:190px;display:block;margin:4px auto 0">
    <path d="M ${cx-r} ${cy} A ${r} ${r} 0 0 1 ${cx+r} ${cy}" fill="none" stroke="var(--bd)" stroke-width="11" stroke-linecap="round"/>
    <path d="M ${cx-r} ${cy} A ${r} ${r} 0 0 1 ${cx+r} ${cy}" fill="none" stroke="${color}" stroke-width="11" stroke-linecap="round" stroke-dasharray="${dash} ${totalLen-dash}"/>
    <text x="${cx}" y="${cy-10}" text-anchor="middle" font-size="15" font-weight="800" fill="${color}" font-family="var(--fn)">${label}</text>
    <text x="${cx}" y="${cy+2}" text-anchor="middle" font-size="8" font-weight="700" fill="var(--tx3)" font-family="var(--fn)">${sub}</text>
  </svg>`;
}

function teamLoadRows(teamLoad,maxLoad){
  if(!teamLoad.length) return `<div style="padding:16px;text-align:center;font-size:12px;color:var(--tx3)">No active task assignments</div>`;
  return teamLoad.map(({m,count,criticalL,highL,overdueL})=>{
    const pct=Math.max(6,Math.round(count/maxLoad*100));
    const loadColor=count>=6?'#dc2626':count>=4?'#c2410c':count>=2?'#b45309':'#15803d';
    const loadLabel=count>=6?'Overloaded':count>=4?'High':count>=2?'Moderate':'Light';
    const chips=[criticalL?`${criticalL}C`:'',highL?`${highL}H`:'',overdueL?`${overdueL}!`:''].filter(Boolean).join(' · ');
    return `<div onclick="openMemberDetail('${m.id}')" onmouseover="this.style.background='var(--s2)'" onmouseout="this.style.background='transparent'" style="display:flex;align-items:center;gap:10px;padding:8px 6px;border-radius:10px;cursor:pointer;transition:background .15s">
      <span style="width:30px;height:30px;border-radius:50%;background:${m.color};display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;color:#fff;flex-shrink:0">${m.av}</span>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:baseline;justify-content:space-between;gap:6px;margin-bottom:5px">
          <span style="font-size:12.5px;font-weight:700;color:var(--tx);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(m.name)}</span>
          <span style="font-size:9px;font-weight:700;color:${loadColor};flex-shrink:0">${loadLabel}</span>
        </div>
        <div style="position:relative;height:8px;background:var(--s2);border-radius:100px;overflow:hidden">
          <div style="position:absolute;inset:0 auto 0 0;width:${pct}%;background:linear-gradient(90deg,${loadColor}99,${loadColor});border-radius:100px;transition:width .6s cubic-bezier(.2,0,0,1)"></div>
        </div>
      </div>
      <div style="text-align:right;flex-shrink:0;min-width:30px">
        <div style="font-size:16px;font-weight:800;color:${loadColor};line-height:1">${count}</div>
        ${chips?`<div style="font-size:8px;font-weight:700;color:var(--tx3);white-space:nowrap;margin-top:2px">${chips}</div>`:''}
      </div>
    </div>`;
  }).join('');
}

function miniBarColumns(items,opts={}){
  const h=opts.height||64;
  const cols=items.map(it=>{
    const v=it.value==null?0:it.value;
    const col=it.color||(v>=80?'#146C2E':v>=50?'#8A5300':'#B3261E');
    return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%">
      <div title="${it.label}: ${it.value==null?'no data':it.value+'%'}" style="width:100%;max-width:22px;background:${it.value==null?'var(--s2)':col};border-radius:4px 4px 0 0;height:${it.value==null?2:Math.max(3,v/100*h)}px;transition:height .5s"></div>
    </div>`;
  }).join('');
  const labels=items.map(it=>`<div style="flex:1;text-align:center;font-size:8.5px;color:var(--tx3);font-weight:600">${it.label}</div>`).join('');
  return `<div style="display:flex;align-items:flex-end;gap:5px;height:${h}px;margin-bottom:6px">${cols}</div><div style="display:flex;gap:5px">${labels}</div>`;
}

function projectCountdown(pr){
  if(!pr.targetDate) return '';
  if(pr.status==='Completed') return `<span style="display:inline-flex;align-items:center;gap:4px;font-size:10.5px;font-weight:700;color:var(--g);background:var(--gb);padding:2px 9px;border-radius:100px">✓ Completed</span>`;
  const diff=Math.round((new Date(pr.targetDate)-new Date())/86400000);
  if(diff<0) return `<span style="display:inline-flex;align-items:center;gap:4px;font-size:10.5px;font-weight:700;color:var(--r);background:var(--rb);padding:2px 9px;border-radius:100px">${Math.abs(diff)}d overdue</span>`;
  if(diff===0) return `<span style="display:inline-flex;align-items:center;gap:4px;font-size:10.5px;font-weight:700;color:var(--y);background:var(--yb);padding:2px 9px;border-radius:100px">Due today</span>`;
  if(diff<=7) return `<span style="display:inline-flex;align-items:center;gap:4px;font-size:10.5px;font-weight:700;color:var(--o);background:var(--ob);padding:2px 9px;border-radius:100px">${diff}d left</span>`;
  return `<span style="display:inline-flex;align-items:center;gap:4px;font-size:10.5px;font-weight:600;color:var(--tx3);background:var(--s2);padding:2px 9px;border-radius:100px">${diff}d left</span>`;
}

// ══════════════════════════════════════════════════════════════════════
// PROJECTS — portfolio-grade card redesign + quick status filter chips
// ══════════════════════════════════════════════════════════════════════
function rProjects(el){
  const sc={Active:'#3762E4',Planning:'#8A5300',Completed:'#146C2E','On Hold':'#8A4A16',Cancelled:'#B3261E'};
  const allCompanies=[...new Set(DB.projects.map(p=>p.ownedBy||p.company_owner).filter(Boolean))];
  const allFields=[...new Set(DB.projects.map(p=>p.field_of_work).filter(Boolean))];
  const STATUS_CHIPS=['All','Active','Planning','On Hold','Completed','At Risk'];

  function render(){
    const chipSel=document.getElementById('prf-chip')?.dataset.val||'All';
    const fCo=document.getElementById('prf-co')?.value||'';
    const fFi=document.getElementById('prf-fi')?.value||'';
    const sq=(document.getElementById('prf-sq')?.value||'').toLowerCase();
    let prs=[...DB.projects];
    if(fCo) prs=prs.filter(p=>(p.ownedBy||p.company_owner)===fCo);
    if(fFi) prs=prs.filter(p=>p.field_of_work===fFi);
    if(sq)  prs=prs.filter(p=>(p.name||'').toLowerCase().includes(sq));
    if(chipSel==='At Risk'){
      prs=prs.filter(p=>DB.tasks.some(t=>t.projectId===p.id&&!['Done','Cancelled'].includes(t.status)&&getDueStatus(t).key==='overdue'));
    } else if(chipSel!=='All'){
      prs=prs.filter(p=>p.status===chipSel);
    }

    const totalP=DB.projects.length;
    const activeP=DB.projects.filter(p=>p.status==='Active').length;
    const atRiskP=DB.projects.filter(p=>DB.tasks.some(t=>t.projectId===p.id&&!['Done','Cancelled'].includes(t.status)&&getDueStatus(t).key==='overdue')).length;
    const completedP=DB.projects.filter(p=>p.status==='Completed').length;

    let h=`<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
      ${[{l:'Total Projects',v:totalP,c:'#3762E4',ic:'list'},{l:'Active',v:activeP,c:'#146C2E',ic:'gauge'},{l:'At Risk',v:atRiskP,c:atRiskP?'#B3261E':'#146C2E',ic:'alert'},{l:'Completed',v:completedP,c:'#6750A4',ic:'shield'}]
      .map(k=>`<div style="background:var(--s);border:1px solid var(--bd);border-radius:16px;padding:14px 16px;display:flex;align-items:center;gap:12px">
        <div style="width:38px;height:38px;border-radius:12px;background:${k.c}18;color:${k.c};display:flex;align-items:center;justify-content:center;flex-shrink:0">${icon(k.ic,18)}</div>
        <div><div style="font-size:20px;font-weight:500;color:${k.c};line-height:1">${k.v}</div><div style="font-size:10.5px;font-weight:600;color:var(--tx3);margin-top:3px">${k.l}</div></div>
      </div>`).join('')}
    </div>`;

    h+=`<div style="display:flex;gap:6px;margin-bottom:12px;flex-wrap:wrap" id="prf-chip-row">
      ${STATUS_CHIPS.map(s=>`<div class="prf-chip" data-val="${s}" onclick="window._rPrChip('${s}')" style="padding:7px 16px;border-radius:100px;font-size:12.5px;font-weight:600;cursor:pointer;transition:all .15s;${s===chipSel?'background:var(--ac);color:#fff':'background:var(--s2);color:var(--tx2)'}">${s}</div>`).join('')}
    </div>`;

    h+=`<div class="fb" style="margin-bottom:16px">
      <input class="si" id="prf-sq" placeholder="Search projects…" oninput="window._rPr&&window._rPr()" value="${sq}">
      <select class="fs" id="prf-co" onchange="window._rPr&&window._rPr()"><option value="">All companies</option>${allCompanies.map(c=>`<option ${fCo===c?'selected':''}>${c}</option>`).join('')}</select>
      <select class="fs" id="prf-fi" onchange="window._rPr&&window._rPr()"><option value="">All fields</option>${allFields.map(f=>`<option ${fFi===f?'selected':''}>${f}</option>`).join('')}</select>
    </div>
    <input type="hidden" id="prf-chip" data-val="${chipSel}">`;

    if(!prs.length){
      h+=`<div class="empty"><div class="ei">◉</div><div class="et">No projects${DB.projects.length?' match filters':' yet'}</div><div class="es">Click + New Project to create one</div></div>`;
      el.innerHTML=h;return;
    }

    h+=`<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:14px">`;
    prs.forEach(pr=>{
      const tasks=DB.tasks.filter(t=>t.projectId===pr.id);
      const done=tasks.filter(t=>t.status==='Done').length;
      const activeArr=tasks.filter(t=>!['Done','Cancelled'].includes(t.status));
      const overdue=activeArr.filter(t=>getDueStatus(t).key==='overdue').length;
      const activeOk=activeArr.length-overdue;
      const col=sc[pr.status]||'#767B8D';
      const tot=Math.max(tasks.length,1);
      const pctDone=Math.round(done/tot*100), pctOk=Math.round(activeOk/tot*100), pctOd=Math.round(overdue/tot*100);
      const taskMembers=[...new Set(tasks.flatMap(t=>t.assignees?.length?t.assignees:[t.assignedTo]).filter(Boolean))];
      const projMembers=(pr.member_ids||[]);
      const members=[...new Set([...projMembers,...taskMembers])].map(mid=>DB.team.find(m=>m.id===mid)).filter(Boolean);
      const owner=pr.ownedBy||pr.company_owner;
      const relLibCount=(typeof getLibrary==='function'&&(typeof hasLibAccess!=='function'||hasLibAccess()))?getLibrary().filter(it=>it.projectId===pr.id).length:0;
      const relDocCount=DB.docs.filter(d=>{const t=d.fromTask?DB.tasks.find(x=>x.id===d.fromTask):null;return t&&t.projectId===pr.id;}).length;

      h+=`<div class="mc" onclick="openProjectDetail('${pr.id}')" style="padding:0;overflow:hidden;position:relative;display:flex;flex-direction:column">
        <div style="padding:16px 18px 14px">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px">
            <span style="background:${col}18;color:${col};font-size:10.5px;font-weight:700;padding:3px 11px;border-radius:100px;display:inline-flex;align-items:center;gap:5px"><span style="width:6px;height:6px;border-radius:50%;background:${col};display:inline-block"></span>${pr.status}</span>
            ${projectCountdown(pr)}
          </div>
          <div style="font-size:16px;font-weight:600;line-height:1.3;color:var(--tx);margin-bottom:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(pr.name)}</div>
          <div style="display:flex;flex-wrap:wrap;gap:11px;margin-bottom:13px;color:var(--tx3)">
            ${owner?`<span style="display:inline-flex;align-items:center;gap:5px;font-size:11.5px;color:var(--tx2);font-weight:500">${icon('building')} ${owner}</span>`:''}
            ${pr.locationName?`<span style="display:inline-flex;align-items:center;gap:5px;font-size:11.5px;color:var(--tx2);font-weight:500">${icon('pin')} ${pr.locationName}</span>`:''}
            ${pr.link?`<a href="${pr.link}" target="_blank" onclick="event.stopPropagation()" style="display:inline-flex;align-items:center;gap:5px;font-size:11.5px;color:var(--ac);font-weight:600;text-decoration:none">${icon('link')} Link</a>`:''}
          </div>

          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:5px">
            <span style="font-size:11px;font-weight:600;color:var(--tx3)">${tasks.length} task${tasks.length!==1?'s':''}</span>
            <span style="font-size:13px;font-weight:700;color:${col}">${pctDone}% done</span>
          </div>
          <div style="display:flex;height:8px;border-radius:100px;overflow:hidden;background:var(--s2);margin-bottom:10px">
            ${pctDone?`<div style="width:${pctDone}%;background:#146C2E" title="${done} done"></div>`:''}
            ${pctOk?`<div style="width:${pctOk}%;background:#3762E4" title="${activeOk} active"></div>`:''}
            ${pctOd?`<div style="width:${pctOd}%;background:#B3261E" title="${overdue} overdue"></div>`:''}
          </div>
          <div style="display:flex;gap:12px;flex-wrap:wrap;font-size:11px;color:var(--tx3);font-weight:600;margin-bottom:${members.length||relLibCount||relDocCount?'12px':'0'}">
            <span style="color:#146C2E">● ${done} done</span>
            <span style="color:#3762E4">● ${activeOk} active</span>
            ${overdue?`<span style="color:#B3261E">● ${overdue} overdue</span>`:''}
            ${relLibCount?`<span>📖 ${relLibCount}</span>`:''}
            ${relDocCount?`<span>📚 ${relDocCount}</span>`:''}
          </div>
          ${members.length?`<div style="display:flex;align-items:center;justify-content:space-between">
            <div style="display:flex;align-items:center">
              ${members.slice(0,5).map((m,i)=>`<span title="${esc(m.name)}" style="width:26px;height:26px;border-radius:50%;background:${m.color};display:inline-flex;align-items:center;justify-content:center;font-size:9.5px;font-weight:700;color:#fff;border:2px solid var(--s);margin-left:${i>0?'-8px':'0'};flex-shrink:0">${m.av}</span>`).join('')}
              ${members.length>5?`<span style="width:26px;height:26px;border-radius:50%;background:var(--s2);border:2px solid var(--s);display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:var(--tx3);margin-left:-8px">+${members.length-5}</span>`:''}
            </div>
            <span style="font-size:10.5px;color:var(--tx3);font-weight:600">${members.length} member${members.length!==1?'s':''}</span>
          </div>`:''}
        </div>
        <div class="ac" onclick="event.stopPropagation()" style="display:flex;gap:4px;padding:10px 14px;border-top:1px solid var(--bd);background:var(--s2);margin-top:auto">
          <div class="ib" style="color:var(--ac)" title="Add task to this project" onclick="event.stopPropagation();openTaskModal(null,'${pr.id}')">${icon('list',13)}</div>
          <div class="ib edt" onclick="event.stopPropagation();openProjectModal('${pr.id}')">✏</div>
          <div class="ib del" style="margin-left:auto" onclick="event.stopPropagation();delItem('projects','${pr.id}')">🗑</div>
        </div>
      </div>`;
    });
    h+=`</div>`;
    el.innerHTML=h;
  }
  window._rPr=render;
  window._rPrChip=function(s){
    const hid=document.getElementById('prf-chip'); if(hid) hid.dataset.val=s;
    render();
  };
  render();
}

// ══════════════════════════════════════════════════════════════════════
// PROJECT DETAIL PANEL — event-delegated (no fragile inline onclick
// string interpolation), sections reordered: Tasks → Library → Docs.
// This also fixes the "clicking a task tab closes the panel" bug: every
// interactive row now uses data-attributes + a single delegated
// listener on #sp-bd instead of dozens of inline onclick handlers, and
// every handler calls stopPropagation so nothing can bubble out.
// ══════════════════════════════════════════════════════════════════════
window.openProjectDetail=(id)=>{
  const pr=DB.projects.find(x=>x.id===id);if(!pr)return;
  const col={Active:'#3762E4',Planning:'#8A5300',Completed:'#146C2E','On Hold':'#8A4A16',Cancelled:'#B3261E'}[pr.status]||'#767B8D';
  const tasks=DB.tasks.filter(t=>t.projectId===pr.id);
  const done=tasks.filter(t=>t.status==='Done').length;
  const active=tasks.filter(t=>!['Done','Cancelled'].includes(t.status)).length;
  const pct=tasks.length?Math.round(done/tasks.length*100):0;
  const members=[...new Set(tasks.flatMap(t=>t.assignees?.length?t.assignees:[t.assignedTo]).filter(Boolean))];

  let body=`<div class="sg2">
      <div class="spf"><div class="spl">Location</div><div class="spv">${pr.locationName||'—'}</div></div>
      <div class="spf"><div class="spl">Owner</div><div class="spv">${pr.ownedBy||'—'}</div></div>
      <div class="spf"><div class="spl">Started</div><div class="spv">${fd(pr.startedAt)}</div></div>
      <div class="spf"><div class="spl">Target</div><div class="spv">${fd(pr.targetDate)}</div></div>
      ${pr.budget?`<div class="spf"><div class="spl">Budget</div><div class="spv">$${pr.budget.toLocaleString()}</div></div>`:''}
      ${pr.link?`<div class="spf" style="grid-column:1/-1"><div class="spl">Link</div><div class="spv"><a href="${pr.link}" target="_blank" style="color:var(--ac)">${pr.link}</a></div></div>`:''}
    </div>
    ${pr.desc?`<div class="spf"><div class="spl">Description</div><div class="spnote">${esc(pr.desc)}</div></div>`:''}
    <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--tx3);margin-bottom:5px;margin-top:12px"><span>${tasks.length} total tasks</span><span style="font-weight:700;color:${col}">${pct}%</span></div>
    <div class="prg" style="height:6px;margin-bottom:10px"><div class="prf" style="width:${pct}%;background:${col}"></div></div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-bottom:12px">
      ${[['Done',done,'#146C2E'],['Active',active,'#3762E4'],['Total',tasks.length,'#767B8D']].map(([l,v,c])=>`<div style="background:${c}12;border:1px solid ${c}25;border-radius:8px;padding:8px;text-align:center"><div style="font-size:9px;color:var(--tx3);font-weight:600;margin-bottom:2px;text-transform:uppercase">${l}</div><div style="font-size:16px;font-weight:700;color:${c}">${v}</div></div>`).join('')}
    </div>
    ${members.length?`<div class="spl" style="margin-bottom:6px">Team (${members.length})</div><div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:14px">${members.map(mid=>{const m=DB.team.find(x=>x.id===mid);return m?`<span style="background:${m.color}22;color:${m.color};border:1px solid ${m.color}33;font-size:10px;font-weight:600;padding:2px 9px;border-radius:20px">${esc(m.name)}</span>`:''}).join('')}</div>`:''}

    <div id="proj-tasks-wrap"></div>

    <div id="proj-lib-wrap" style="margin-top:16px"></div>

    <div id="proj-docs-wrap" style="margin-top:16px"></div>

    <div class="spa">
      <button class="btn bg2 bsm" data-act="edit-project">✏ Edit</button>
      <button class="btn bd2 bsm" data-act="delete-project">Delete</button>
    </div>`;

  openSP(pr.name,`<span style="background:${col}18;color:${col};border:none;font-size:10px;font-weight:700;padding:2px 10px;border-radius:100px">${pr.status}</span>`,body);

  // ── single delegated click handler for the whole panel — robust
  // against quote-escaping issues and prevents any bubble-out closes ──
  const spBd=document.getElementById('sp-bd');
  if(spBd && !spBd._projDelegated){
    spBd._projDelegated=true;
    spBd.addEventListener('click',(e)=>{
      const actEl=e.target.closest('[data-act]');
      if(!actEl) return;
      e.preventDefault(); e.stopPropagation();
      const act=actEl.dataset.act;
      const pid=actEl.dataset.pid;
      const tid=actEl.dataset.tid;
      const did=actEl.dataset.did;
      const lid=actEl.dataset.lid;
      const tab=actEl.dataset.tab;
      if(act==='edit-project') openProjectModal(spBd._curProjectId);
      else if(act==='delete-project'){const p=DB.projects.find(x=>x.id===spBd._curProjectId);if(p)delItem('projects',p.id);closeSP();}
      else if(act==='open-task') openTask(tid);
      else if(act==='add-task') openTaskModal(null,spBd._curProjectId);
      else if(act==='view-all-tasks'){closeSP();window._navProject=spBd._curProjectId;navTo('alltasks');}
      else if(act==='task-tab') renderProjectTasksList(spBd._curProjectId,tab);
      else if(act==='open-lib') openLibEntry(lid);
      else if(act==='add-lib') openLibModal(null,spBd._curProjectId);
      else if(act==='open-doc') openDoc2(did);
    });
  }
  spBd._curProjectId=pr.id;

  renderProjectTasksList(pr.id);
  renderProjectLibraryList(pr.id);
  renderProjectDocsList(pr.id);
};

// Tasks section (first, per request) — data-attributes only, no inline onclick
window.renderProjectTasksList=(projectId,tab)=>{
  const wrap=document.getElementById('proj-tasks-wrap');
  if(!wrap) return;
  tab=tab||wrap.dataset.tab||'Active';
  wrap.dataset.tab=tab;
  const all=DB.tasks.filter(t=>t.projectId===projectId);
  const TABS=['Active','Done','All'];
  const filtered=tab==='All'?all:tab==='Done'?all.filter(t=>t.status==='Done'):all.filter(t=>!['Done','Cancelled'].includes(t.status));
  const shown=filtered.slice(0,15);

  let h=`<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:9px;flex-wrap:wrap;gap:6px">
    <div class="spl" style="margin-bottom:0">📋 Tasks (${all.length})</div>
    <button class="btn bp bxs" data-act="add-task">+ Add Task</button>
  </div>
  <div class="tabs" style="margin-bottom:9px">
    ${TABS.map(tb=>`<div class="tab ${tb===tab?'on':''}" data-act="task-tab" data-tab="${tb}" style="font-size:12px">${tb} <span style="opacity:.5;font-size:10px">${tb==='All'?all.length:tb==='Done'?all.filter(t=>t.status==='Done').length:all.filter(t=>!['Done','Cancelled'].includes(t.status)).length}</span></div>`).join('')}
  </div>`;

  if(!filtered.length){
    h+=`<div style="text-align:center;padding:16px 0;font-size:12px;color:var(--tx3)">No ${tab==='All'?'':tab.toLowerCase()+' '}tasks yet${tab!=='Done'?' — click + Add Task above':''}</div>`;
  } else {
    h+=shown.map(t=>{
      const ds=getDueStatus(t);
      const ass=DB.team.find(m=>m.id===t.assignedTo);
      return`<div data-act="open-task" data-tid="${t.id}" style="display:flex;align-items:center;gap:7px;padding:8px 0;border-bottom:1px solid var(--bd);cursor:pointer">
        ${spill(t.status)}
        <span style="font-size:12px;font-weight:500;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(t.title)}</span>
        ${ass?`<span style="width:18px;height:18px;border-radius:50%;background:${ass.color};display:inline-flex;align-items:center;justify-content:center;font-size:7px;color:#fff;font-weight:800;flex-shrink:0" title="${esc(ass.name)}">${ass.av}</span>`:''}
        ${ppill(t.priority)}
        <span class="due-badge ${ds.cls}" style="flex-shrink:0">${ds.label}</span>
      </div>`;
    }).join('');
    if(filtered.length>shown.length){
      h+=`<div data-act="view-all-tasks" style="text-align:center;padding:9px 0;font-size:11px;color:var(--ac);font-weight:700;cursor:pointer">+${filtered.length-shown.length} more — view all in All Tasks →</div>`;
    } else if(all.length){
      h+=`<div data-act="view-all-tasks" style="text-align:center;padding:9px 0;font-size:11px;color:var(--ac);font-weight:700;cursor:pointer">View in All Tasks →</div>`;
    }
  }
  wrap.innerHTML=h;
};

// Library section (second)
window.renderProjectLibraryList=(projectId)=>{
  const wrap=document.getElementById('proj-lib-wrap');
  if(!wrap) return;
  if(typeof hasLibAccess==='function' && !hasLibAccess()){ wrap.innerHTML=''; return; }
  const relLib=(typeof getLibrary==='function'?getLibrary():[]).filter(it=>it.projectId===projectId);
  const chips=relLib.map(it=>`<span data-act="open-lib" data-lid="${it.id}" style="cursor:pointer;background:var(--al);color:var(--ac);border:none;font-size:10.5px;font-weight:700;padding:4px 11px;border-radius:100px">📖 ${it.topic}</span>`).join('');
  wrap.innerHTML=`<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
    <div class="spl" style="margin-bottom:0">📖 Library (${relLib.length})</div>
    <button class="btn bp bxs" data-act="add-lib">+ Add</button>
  </div>
  <div style="display:flex;flex-wrap:wrap;gap:6px">
    ${chips||'<span style="font-size:11px;color:var(--tx3)">No entries linked yet</span>'}
  </div>`;
};

// Documentation section (third)
window.renderProjectDocsList=(projectId)=>{
  const wrap=document.getElementById('proj-docs-wrap');
  if(!wrap) return;
  const relDocs=DB.docs.filter(d=>{const t=d.fromTask?DB.tasks.find(x=>x.id===d.fromTask):null;return t&&t.projectId===projectId;});
  if(!relDocs.length){ wrap.innerHTML=''; return; }
  wrap.innerHTML=`<div class="spl" style="margin-bottom:8px">📚 Documentation (${relDocs.length})</div>
  <div style="display:flex;flex-wrap:wrap;gap:6px">${relDocs.map(d=>`<span data-act="open-doc" data-did="${d.id}" style="cursor:pointer;background:var(--gb);color:var(--g);border:none;font-size:10.5px;font-weight:700;padding:4px 11px;border-radius:100px">📚 ${esc(d.title)}</span>`).join('')}</div>`;
};

// ══════════════════════════════════════════════════════════════════════
// DASHBOARD — corporate, chart-driven, built for CEO / HR / PM / Team Lead
// ══════════════════════════════════════════════════════════════════════
// §10 ── DASHBOARD ───────────────────────────────────────────────────────
function rDash(el){
  const todayStr=localDateStr();
  const todayDow=new Date().getDay();
  const now=new Date();

  // Single source of truth for "is this task assigned to this member" —
  // checks id match, assignees array (by id), and case-insensitive name
  // fallback on both assignedTo and assignees. Used everywhere below so
  // done/active/rejected counts stay consistent with each other.
  const taskAssignedToMember=(t,m)=>{
    if(!m)return false;
    const nm=(m.name||'').toLowerCase();
    return t.assignedTo===m.id||
      (t.assignees||[]).includes(m.id)||
      (t.assignedTo||'').toLowerCase()===nm||
      (t.assignees||[]).some(a=>(a||'').toLowerCase()===nm);
  };

  // ── Core data aggregations ──────────────────────────────────────────
  const allTasks=DB.tasks;
  const activeTasks=allTasks.filter(t=>!['Done','Cancelled'].includes(t.status));
  const doneTasks=allTasks.filter(t=>t.status==='Done');
  const myTasks=isAdmin()?activeTasks:activeTasks.filter(t=>t.assignedTo===CU.id||t.assignees?.includes(CU.id));

  const overdue=activeTasks.filter(t=>getDueStatus(t).key==='overdue');
  const pendingRev=allTasks.filter(t=>t.status==='Pending Review');
  const newTasks=allTasks.filter(t=>t.status==='New');
  const inProg=allTasks.filter(t=>t.status==='In Progress');
  const rejected=allTasks.filter(t=>t.status==='Rejected');

  // ── KPI calculations ────────────────────────────────────────────────
  const taskCompletionRate=allTasks.length?Math.round(doneTasks.length/allTasks.length*100):0;
  const overdueRate=activeTasks.length?Math.round(overdue.length/activeTasks.length*100):0;

  // Avg cycle time from done tasks that have cycle_h
  const tasksWithCycle=doneTasks.filter(t=>t.cycleH&&t.cycleH>0);
  const avgCycleH=tasksWithCycle.length?Math.round(tasksWithCycle.reduce((a,t)=>a+t.cycleH,0)/tasksWithCycle.length):null;

  // Service health (from tests)
  const testChecks=DB.testChecks||[];
  const doneChecks=testChecks.filter(c=>c.result!=='pending');
  const passChecks=testChecks.filter(c=>c.result==='pass');
  const serviceHealth=doneChecks.length?Math.round(passChecks.length/doneChecks.length*100):null;

  // Meetings this week
  const weekStart=new Date(now); weekStart.setDate(now.getDate()-now.getDay());
  const weekEnd=new Date(weekStart); weekEnd.setDate(weekStart.getDate()+6);
  const weekMeetings=DB.meetings.filter(m=>{const d=new Date(m.meeting_date);return d>=weekStart&&d<=weekEnd;});
  const todayMeetings=DB.meetings.filter(m=>m.meeting_date===todayStr&&m.status==='Scheduled'&&(m.created_by===CU.name||m.invitees?.includes(CU.name)||isAdmin()));

  // Team utilization — % of members with active tasks
  const membersWithTasks=DB.team.filter(m=>activeTasks.some(t=>t.assignedTo===m.id||t.assignees?.includes(m.id))).length;
  const teamUtilization=DB.team.length?Math.round(membersWithTasks/DB.team.length*100):0;

  // Pipeline velocity — tasks completed in last 7 days
  const last7=new Date(now); last7.setDate(now.getDate()-7);
  const recentDone=doneTasks.filter(t=>t.tsReviewed&&new Date(t.tsReviewed)>=last7).length;

  let h='';

  if(!isAdmin()){
    // ── MEMBER VIEW ─────────────────────────────────────────────────
    const isMine=t=>taskAssignedToMember(t,CU);
    // activeTasks only excludes Done/Cancelled — Rejected tasks are still
    // in there. Since Rejected now gets its own stat box, "mine" (used for
    // the Active count, My Tasks list, Overdue, Near-due, New) must exclude
    // Rejected too, or a rejected task gets counted twice on the dashboard.
    // mineAll keeps Rejected in the completion-rate denominator, same as before.
    const mineAll=activeTasks.filter(isMine);
    const mine=mineAll.filter(t=>t.status!=='Rejected');
    const myDone=doneTasks.filter(isMine);
    const myOverdue=mine.filter(t=>getDueStatus(t).key==='overdue');
    const myNearDue=mine.filter(t=>{const k=getDueStatus(t).key;return k==='soon'||k==='today';});
    const myNewTasks=mine.filter(t=>t.status==='New');
    const myRev=allTasks.filter(t=>(t.reviewer===CU.id||(t.reviewer||'').toLowerCase()===CU.name.toLowerCase())&&t.status==='Pending Review');
    const myRate=mineAll.length+myDone.length?Math.round(myDone.length/(mineAll.length+myDone.length)*100):0;
    const myRejected=allTasks.filter(t=>isMine(t)&&t.status==='Rejected').length;

    // Response time (created → opened) and completion/cycle time, for the
    // two boxes that replace the plain Completion Rate stat.
    const fmtHrs=h=>{
      if(h==null)return'—';
      if(h<1)return Math.round(h*60)+'m';
      if(h<48)return (Math.round(h*10)/10)+'h';
      return (Math.round(h/24*10)/10)+'d';
    };
    const myRespTasks=allTasks.filter(t=>isMine(t)&&t.tsOpened&&t.tsCreated);
    const avgRespH=myRespTasks.length?myRespTasks.reduce((s,t)=>s+((new Date(t.tsOpened)-new Date(t.tsCreated))/3600000),0)/myRespTasks.length:null;
    const myCycleTasks=myDone.filter(t=>t.cycleH&&t.cycleH>0);
    const avgCycleH=myCycleTasks.length?myCycleTasks.reduce((s,t)=>s+t.cycleH,0)/myCycleTasks.length:null;

    // Done this week / month — all derived from the same myDone set above,
    // so "Today"/"Week"/"Month"/"all-time" numbers can never drift apart.
    const last7d=new Date(now);last7d.setDate(now.getDate()-7);
    const last30d=new Date(now);last30d.setDate(now.getDate()-30);
    const doneThisWeek=myDone.filter(t=>t.tsReviewed&&new Date(t.tsReviewed)>=last7d);
    const doneThisMonth=myDone.filter(t=>t.tsReviewed&&new Date(t.tsReviewed)>=last30d);
    const doneToday=myDone.filter(t=>t.tsReviewed&&localDateStr(new Date(t.tsReviewed))===todayStr);

    // ── Performance note ──────────────────────────────────────────
    function perfNote(rate,overdue,rejected,active,doneW,newCount,nearDueCount){
      // Grade
      let grade,color,icon;
      if(rate>=90&&overdue===0)      {grade='Excellent';color='#15803d';icon='🌟';}
      else if(rate>=75&&overdue<=1)  {grade='Good';color='#2563eb';icon='✅';}
      else if(rate>=50)              {grade='Average';color='#d97706';icon='📈';}
      else if(active>0&&rate<30)     {grade='Needs focus';color='#dc2626';icon='⚠️';}
      else                           {grade='Getting started';color='#6366f1';icon='🚀';}

      // Build note lines — overdue and unopened/delayed tasks lead and are
      // flagged for emphasis (the two things most worth a member's
      // attention); good progress and near-due follow at normal weight.
      const lines=[];
      lines.push({emphasis:true,c:overdue>0?'#dc2626':'#15803d',
        text:overdue>0?`🔴 ${overdue} task${overdue>1?'s':''} overdue — prioritise ${overdue>1?'these':'this'} first.`:`🟢 Nothing overdue — all on track.`});
      lines.push({emphasis:true,c:newCount>0?'#ea580c':'#15803d',
        text:newCount>0?`🆕 ${newCount} new task${newCount>1?'s':''} not opened yet — don't let these sit.`:`🆕 No new unopened tasks.`});

      if(doneW>0) lines.push({emphasis:false,text:`✅ ${doneW} task${doneW>1?'s':''} completed this week — great progress.`});
      else if(rate>=80) lines.push({emphasis:false,text:`✅ ${rate}% completion rate — strong work, keep it up.`});
      else if(active===0&&doneW===0) lines.push({emphasis:false,text:`🚀 No tasks yet — check All Tasks for new assignments.`});

      lines.push({emphasis:false,text:nearDueCount>0?`🟡 ${nearDueCount} task${nearDueCount>1?'s':''} due within 2 days — plan ahead.`:`🟡 Nothing due soon.`});

      if(rejected>0) lines.push({emphasis:false,text:`❌ ${rejected} task${rejected>1?'s':''} rejected — review the feedback carefully.`});
      if(myRev.length>0) lines.push({emphasis:false,text:`📝 ${myRev.length} task${myRev.length>1?'s':''} waiting for your review.`});

      return {grade,color,icon,lines};
    }
    const {grade,color,icon,lines:noteLines}=perfNote(myRate,myOverdue.length,myRejected,mine.length,doneThisWeek.length,myNewTasks.length,myNearDue.length);

    // Per-metric status: gives each stat box its own arrow + colored label
    // so the member can tell at a glance where they stand on that metric,
    // independent of the overall Member Notice grade above.
    function statusLevel(kind,val){
      const T=(label,c,arrow)=>({label,c,arrow});
      switch(kind){
        case 'load':
          if(val===0)  return T('Very Good','#15803d','↑');
          if(val<=5)   return T('Good','#2563eb','↗');
          if(val<=10)  return T('Needs Attention','#ea580c','↘');
          return T('Poor','#dc2626','↓');
        case 'overdue':
        case 'rejected':
          if(val===0)  return T('Very Good','#15803d','↑');
          if(val===1)  return T('Needs Attention','#ea580c','↘');
          return T('Poor','#dc2626','↓');
        case 'resp':
          if(val==null) return T('No Data','#94a3b8','–');
          if(val<=1)   return T('Very Good','#15803d','↑');
          if(val<=4)   return T('Good','#2563eb','↗');
          if(val<=24)  return T('Needs Attention','#ea580c','↘');
          return T('Poor','#dc2626','↓');
        case 'cycle':
          if(val==null) return T('No Data','#94a3b8','–');
          if(val<=24)  return T('Very Good','#15803d','↑');
          if(val<=72)  return T('Good','#2563eb','↗');
          if(val<=168) return T('Needs Attention','#ea580c','↘');
          return T('Poor','#dc2626','↓');
        default: return T('','#94a3b8','–');
      }
    }
    function statusBadge(kind,val){
      const s=statusLevel(kind,val);
      return `<div style="display:inline-flex;align-items:center;gap:4px;margin-top:6px;font-size:10px;font-weight:800;color:${s.c};background:${s.c}18;border:1px solid ${s.c}33;padding:2px 8px;border-radius:20px">
        <span style="font-size:11px;line-height:1">${s.arrow}</span><span>${s.label}</span>
      </div>`;
    }

    // ── STAT CARDS ────────────────────────────────────────────────
    h+=`<div class="sg" style="margin-bottom:14px;overflow:hidden">
      <div class="stat" style="min-width:0;overflow:hidden" onclick="navTo('mytasks','New')"><div class="st-bar" style="background:#94a3b8"></div><div class="st-lbl">New</div><div class="st-val" style="color:#94a3b8">${myNewTasks.length}</div><div class="st-sub">${myNewTasks.length?'not started yet':'nothing new'}</div></div>
      <div class="stat" style="min-width:0;overflow:hidden" onclick="navTo('mytasks')"><div class="st-bar" style="background:#2563eb"></div><div class="st-lbl">My Active Tasks</div><div class="st-val" style="color:#2563eb">${mine.length}</div><div class="st-sub">${myDone.length} completed all-time</div>${statusBadge('load',mine.length)}</div>
      <div class="stat" style="min-width:0;overflow:hidden" onclick="navTo('mytasks','Overdue')"><div class="st-bar" style="background:${myOverdue.length?'#dc2626':'#15803d'}"></div><div class="st-lbl">Overdue</div><div class="st-val" style="color:${myOverdue.length?'#dc2626':'#15803d'}">${myOverdue.length}</div>${statusBadge('overdue',myOverdue.length)}</div>
      <div class="stat" style="min-width:0;overflow:hidden" onclick="navTo('toreview')"><div class="st-bar" style="background:#7c3aed"></div><div class="st-lbl">To Review</div><div class="st-val" style="color:#7c3aed">${myRev.length}</div><div class="st-sub">${myRev.length?'awaiting your review':'nothing pending'}</div></div>
      <div class="stat" style="min-width:0;overflow:hidden"><div class="st-bar" style="background:#0891b2"></div><div class="st-lbl">Avg Response</div><div class="st-val" style="color:#0891b2">${fmtHrs(avgRespH)}</div>${statusBadge('resp',avgRespH)}</div>
      <div class="stat" style="min-width:0;overflow:hidden"><div class="st-bar" style="background:#ea580c"></div><div class="st-lbl">Avg Completion</div><div class="st-val" style="color:#ea580c">${fmtHrs(avgCycleH)}</div>${statusBadge('cycle',avgCycleH)}</div>
      <div class="stat" style="min-width:0;overflow:hidden" onclick="navTo('mytasks','Rejected')"><div class="st-bar" style="background:#dc2626"></div><div class="st-lbl">Rejected</div><div class="st-val" style="color:#dc2626">${myRejected}</div>${statusBadge('rejected',myRejected)}</div>
    </div>`;


    // ── BEST OF THE WEEK data (used in the row below) ─────────────
    const bowStart=new Date();bowStart.setDate(bowStart.getDate()-6);
    const bowScores=DB.team.filter(m=>m.access!=='Admin'&&!FULL.includes(m.name)&&!AROLES.includes(m.role)).map(m=>{
      const doneW=DB.tasks.filter(t=>t.status==='Done'&&taskAssignedToMember(t,m)&&t.tsReviewed&&new Date(t.tsReviewed)>=bowStart).length;
      const overdueW=DB.tasks.filter(t=>!['Done','Cancelled'].includes(t.status)&&taskAssignedToMember(t,m)&&getDueStatus(t).key==='overdue').length;
      return{m,doneW,overdueW,score:doneW*3-overdueW*2};
    }).filter(x=>x.doneW>0||x.overdueW>0).sort((a,b)=>b.score-a.score);
    const bow=bowScores[0];

    // ── GRID: left column (60%) = My Tasks → Member Notice, right column (40%) = Tasks Done → Employee of the Week ──
    h+=`<div style="display:grid;grid-template-columns:3fr 2fr;gap:14px;margin-bottom:14px;overflow:hidden">
      <div style="display:flex;flex-direction:column;gap:14px;min-width:0">
        <div class="card" style="min-width:0;overflow:hidden;padding:18px">
          <div class="ct" style="margin-bottom:16px"><span class="ct-t" style="font-weight:800;font-size:16px">📋 My Tasks</span></div>
          ${mine.length?mine.slice(0,6).map(t=>{const ds=getDueStatus(t);return`<div onclick="openTask('${t.id}')" style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--bd);cursor:pointer">
            ${spill(t.status)}
            <span style="flex:1;font-size:13.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(t.title)}</span>
            <span class="${ds.cls}" style="font-size:11px;flex-shrink:0">${ds.label}</span>
          </div>`;}).join('')+
          (mine.length>6?`<div style="font-size:12px;color:var(--ac);margin-top:10px;cursor:pointer" onclick="navTo('mytasks')">View all ${mine.length} tasks →</div>`:'')
          :`<div style="text-align:center;padding:24px 0;font-size:13px;color:var(--tx3)">No active tasks — you're all clear!</div>`}
        </div>

        <div style="background:${color}12;border:1px solid ${color}33;border-radius:14px;padding:16px;min-width:0">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
            <span style="font-size:20px;line-height:1">${icon}</span>
            <span style="font-size:13px;font-weight:800;color:${color}">${grade}</span>
            <span style="font-size:9px;font-weight:800;background:${color}22;color:${color};padding:2px 8px;border-radius:20px;margin-left:auto">Member Notice</span>
          </div>
          <div style="display:flex;flex-direction:column;gap:9px">
            ${noteLines.map(l=>l.emphasis?
              `<div style="font-size:13px;font-weight:800;color:${l.c};background:${l.c}15;border:1px solid ${l.c}30;border-radius:9px;padding:8px 10px;line-height:1.4">${esc(l.text)}</div>`
              :`<div style="font-size:11px;color:var(--tx2);line-height:1.5">${esc(l.text)}</div>`
            ).join('')}
          </div>
        </div>
      </div>

      <div style="display:flex;flex-direction:column;gap:14px;min-width:0">
        <div style="background:linear-gradient(135deg,#15803d,#059669);border-radius:8px;padding:8px 14px;min-width:0;display:flex;align-items:center;gap:10px;overflow:hidden;box-shadow:0 2px 10px #15803d4d">
          <span style="font-size:11.5px;font-weight:900;color:#fff;text-transform:uppercase;letter-spacing:.05em;flex-shrink:0;white-space:nowrap">🏆 Employee of the Week</span>
          ${bow?`<span style="width:4px;height:4px;border-radius:50%;background:#ffffff80;flex-shrink:0"></span>
          <span style="font-size:15px;font-weight:900;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0">${esc(bow.m.name)}</span>
          <span style="font-size:12px;color:#fff;font-weight:800;flex-shrink:0;white-space:nowrap;margin-left:auto;background:#ffffff30;padding:3px 10px;border-radius:20px">⭐ ${bow.doneW} task${bow.doneW!==1?'s':''} done</span>`
          :`<span style="font-size:11.5px;color:#ffffffcc;white-space:nowrap">Not enough activity yet</span>`}
        </div>

        <div class="card" style="min-width:0;overflow:hidden">
          <div class="ct"><span class="ct-t">✅ Tasks Done</span></div>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px">
            ${[{l:'Today',v:doneToday.length,c:'#2563eb'},{l:'This Week',v:doneThisWeek.length,c:'#15803d'},{l:'This Month',v:doneThisMonth.length,c:'#7c3aed'}].map(({l,v,c})=>`
            <div style="background:${c}11;border:1px solid ${c}22;border-radius:8px;padding:10px;text-align:center">
              <div style="font-size:22px;font-weight:800;color:${c};line-height:1">${v}</div>
              <div style="font-size:10px;font-weight:600;color:${c};margin-top:3px">${l}</div>
            </div>`).join('')}
          </div>
          ${doneThisWeek.length?`<div>
            ${doneThisWeek.slice(0,4).map(t=>`<div onclick="openTask('${t.id}')" style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--bd);cursor:pointer">
              <span style="width:7px;height:7px;border-radius:50%;background:#15803d;flex-shrink:0"></span>
              <span style="flex:1;font-size:12px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(t.title)}</span>
              <span style="font-size:10px;color:var(--tx3);flex-shrink:0">${fr(t.tsReviewed)}</span>
            </div>`).join('')}
            ${doneThisWeek.length>4?`<div style="font-size:11px;color:var(--ac);margin-top:6px;cursor:pointer" onclick="navTo('archive')">+${doneThisWeek.length-4} more in Archive →</div>`:''}
          </div>`:
          `<div style="text-align:center;padding:10px 0;font-size:12px;color:var(--tx3)">No completed tasks this week yet</div>`}
        </div>
      </div>
    </div>`;

    // ── MEETING ATTENDANCE BANNER ────────────────────────────────
    const ms=getMeetingStats(CU.name,30);
    if(ms.invited.length>0||ms.upcoming.length>0){
      const hasMissed=ms.missed.length>0;
      const hasAttended=ms.attended.length>0;
      const bColor=ms.missed.length>0&&ms.attended.length===0?'#dc2626':ms.rate>=80?'#15803d':ms.rate>=50?'#d97706':'#dc2626';
      const bBg=ms.missed.length>0&&ms.attended.length===0?'#fef2f2':ms.rate>=80?'#f0fdf4':ms.rate>=50?'#fffbeb':'#fef2f2';
      const bBorder=ms.missed.length>0&&ms.attended.length===0?'#fca5a5':ms.rate>=80?'#86efac':ms.rate>=50?'#fde68a':'#fca5a5';
      // Build lines
      const mLines=[];
      if(ms.missed.length>0){
        mLines.push(`⚠️ You missed ${ms.missed.length} meeting${ms.missed.length>1?'s':''} in the last 30 days: ${ms.missed.map(m=>m.title).join(', ')}.`);
        mLines.push('Missing meetings affects your evaluation score. Please ensure you attend scheduled meetings.');
      }
      if(ms.attended.length>0&&ms.missed.length===0){
        mLines.push(`✅ Great job! You attended all ${ms.attended.length} meeting${ms.attended.length>1?'s':''} in the last 30 days.`);
        mLines.push('Your perfect attendance is reflected positively in your evaluation.');
      } else if(ms.attended.length>0&&ms.missed.length>0){
        mLines.push(`📅 You attended ${ms.attended.length} of ${ms.invited.length} meetings (${ms.rate}% attendance rate).`);
      }
      if(ms.upcoming.length>0){
        mLines.push(`📌 Upcoming: ${ms.upcoming.slice(0,3).map(m=>m.title+' on '+m.meeting_date).join(', ')}.`);
      }
      const mIcon=ms.rate===null?'📅':ms.rate===100?'🏆':ms.rate>=80?'✅':ms.rate>=50?'📉':'❌';
      h+=`<div style="background:${bBg};border:1px solid ${bBorder};border-left:4px solid ${bColor};border-radius:9px;padding:9px 13px;margin-bottom:10px;display:flex;align-items:center;gap:10px">
        <span style="font-size:18px;flex-shrink:0">${mIcon}</span>
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap">
            <span style="font-size:12px;font-weight:700;color:${bColor}">Meetings</span>
            ${ms.rate!==null?`<span style="font-size:11px;font-weight:600;background:${bColor}18;color:${bColor};padding:1px 8px;border-radius:20px">${ms.rate}% · ${ms.attended.length}/${ms.invited.length}</span>`:''}
            <span style="font-size:11px;color:var(--tx3)">${mLines[0]||''}</span>
          </div>
          ${ms.missed.length?`<div style="margin-top:5px;display:flex;flex-wrap:wrap;gap:4px">${ms.missed.slice(0,3).map(m=>`<span onclick="openMeetingDetail('${m.id}')" style="background:#fef2f2;color:#dc2626;border:1px solid #fca5a5;font-size:9px;font-weight:700;padding:2px 7px;border-radius:20px;cursor:pointer">⚠ ${esc(m.title)}</span>`).join('')}</div>`:''}
        </div>
      </div>`;
    }

    // ── TODAY'S MEETINGS ─────────────────────────────────────────
    if(todayMeetings.length){
      h+=`<div class="card" style="margin-bottom:12px"><div class="ct">📅 Today's Meetings</div>
        ${todayMeetings.map(m=>`<div onclick="openMeetingDetail('${m.id}')" style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--bd);cursor:pointer">
          <span style="font-size:15px;font-weight:800;color:var(--ac);width:46px;flex-shrink:0">${m.meeting_time||'—'}</span>
          <div><div style="font-size:13px;font-weight:600">${esc(m.title)}</div><div style="font-size:11px;color:var(--tx3)">${m.location||m.meeting_type||''} · ${m.duration_minutes||60}min</div></div>
          ${spill(m.status)}
        </div>`).join('')}
      </div>`;
    }

    el.innerHTML=h;
    return;
  }

  // ══════════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════════
  // ADMIN DASHBOARD
  // ══════════════════════════════════════════════════════════════════

  // Projects health KPI
  const activeProj=DB.projects.filter(p=>p.status==='Active').length;
  const completedProj=DB.projects.filter(p=>p.status==='Completed').length;
  const onHoldProj=DB.projects.filter(p=>p.status==='On Hold').length;
  const projHealth=DB.projects.length?Math.round((completedProj*1+activeProj*0.5)/Math.max(DB.projects.length,1)*100):null;

  // Day-over-day trend — compares today's values against the most recent
  // prior day we have a snapshot for (see dashSnapshot()).
  const priorSnap=dashSnapshot({
    completionRate:taskCompletionRate, overdueRate, projHealth, serviceHealth,
    total:allTasks.length, newT:newTasks.length, inProgress:inProg.length,
    review:pendingRev.length, done:doneTasks.length, rejected:rejected.length,
    overdueCount:overdue.length,
  });

  // ROW 1: KPI Cards
  h+=`<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px">
    <div onclick="navTo('alltasks')" style="background:linear-gradient(135deg,#1e40af,#2563eb);border-radius:12px;padding:16px;cursor:pointer;position:relative;overflow:hidden">
      <div style="position:absolute;right:-8px;top:-8px;font-size:60px;opacity:.07">📋</div>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:5px">
        <div style="font-size:11px;font-weight:700;color:#93c5fd;text-transform:uppercase;letter-spacing:.07em">Completion Rate</div>
        ${dchip(priorSnap,'completionRate',taskCompletionRate,false)}
      </div>
      <div style="font-size:38px;font-weight:800;color:#fff;line-height:1;margin-bottom:3px">${taskCompletionRate}%</div>
      <div style="font-size:12px;color:#bfdbfe">${doneTasks.length} done · ${activeTasks.length} active</div>
      <div style="height:3px;background:rgba(255,255,255,.2);border-radius:2px;margin-top:10px"><div style="height:100%;width:${taskCompletionRate}%;background:#60a5fa;border-radius:2px"></div></div>
    </div>
    <div onclick="navTo('alltasks','Overdue')" style="background:linear-gradient(135deg,${overdueRate>20?'#991b1b,#dc2626':overdueRate>5?'#92400e,#d97706':'#14532d,#16a34a'});border-radius:12px;padding:16px;cursor:pointer;position:relative;overflow:hidden">
      <div style="position:absolute;right:-8px;top:-8px;font-size:60px;opacity:.07">⚠</div>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:5px">
        <div style="font-size:11px;font-weight:700;color:${overdueRate>20?'#fca5a5':overdueRate>5?'#fcd34d':'#86efac'};text-transform:uppercase;letter-spacing:.07em">Overdue Rate</div>
        ${dchip(priorSnap,'overdueRate',overdueRate,true)}
      </div>
      <div style="font-size:38px;font-weight:800;color:#fff;line-height:1;margin-bottom:3px">${overdueRate}%</div>
      <div style="font-size:12px;color:rgba(255,255,255,.8)">${overdue.length} tasks overdue</div>
      <div style="font-size:12px;color:rgba(255,255,255,.6);margin-top:6px">${overdueRate<=5?'On Track':overdueRate<=20?'Watch':'Critical'}</div>
    </div>
    <div onclick="navTo('projects')" style="background:linear-gradient(135deg,${projHealth===null?'#374151,#4b5563':projHealth>=70?'#14532d,#15803d':projHealth>=40?'#92400e,#b45309':'#7f1d1d,#dc2626'});border-radius:12px;padding:16px;cursor:pointer;position:relative;overflow:hidden">
      <div style="position:absolute;right:-8px;top:-8px;font-size:60px;opacity:.07">◉</div>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:5px">
        <div style="font-size:11px;font-weight:700;color:${projHealth===null?'#9ca3af':projHealth>=70?'#86efac':projHealth>=40?'#fcd34d':'#fca5a5'};text-transform:uppercase;letter-spacing:.07em">Projects Health</div>
        ${projHealth===null?'':dchip(priorSnap,'projHealth',projHealth,false)}
      </div>
      <div style="font-size:38px;font-weight:800;color:#fff;line-height:1;margin-bottom:3px">${projHealth!==null?projHealth+'%':'—'}</div>
      <div style="font-size:12px;color:rgba(255,255,255,.8)">${activeProj} active · ${completedProj} done</div>
      <div style="font-size:12px;color:rgba(255,255,255,.6);margin-top:6px">${projHealth===null?'No projects':projHealth>=70?'Healthy':projHealth>=40?'Monitor':'Attention'}</div>
    </div>
    <div onclick="navTo('svctest')" style="background:linear-gradient(135deg,${serviceHealth===null?'#374151,#4b5563':serviceHealth>=80?'#14532d,#15803d':serviceHealth>=60?'#92400e,#b45309':'#7f1d1d,#dc2626'});border-radius:12px;padding:16px;cursor:pointer;position:relative;overflow:hidden">
      <div style="position:absolute;right:-8px;top:-8px;font-size:60px;opacity:.07">🧪</div>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:5px">
        <div style="font-size:11px;font-weight:700;color:${serviceHealth===null?'#9ca3af':serviceHealth>=80?'#86efac':serviceHealth>=60?'#fcd34d':'#fca5a5'};text-transform:uppercase;letter-spacing:.07em">Service Health</div>
        ${serviceHealth===null?'':dchip(priorSnap,'serviceHealth',serviceHealth,false)}
      </div>
      <div style="font-size:38px;font-weight:800;color:#fff;line-height:1;margin-bottom:3px">${serviceHealth!==null?serviceHealth+'%':'—'}</div>
      <div style="font-size:12px;color:rgba(255,255,255,.8)">${doneChecks.length} checks · ${passChecks.length} passed</div>
      <div style="font-size:12px;color:rgba(255,255,255,.6);margin-top:6px">${serviceHealth===null?'No tests':serviceHealth>=80?'All Good':serviceHealth>=60?'Some Issues':'Failing'}</div>
    </div>
  </div>`;

  // ROW 2: Task Status (8 boxes — everything)
  h+=`<div style="display:grid;grid-template-columns:repeat(8,1fr);gap:7px;margin-bottom:14px">
    ${[
      {l:'Total',v:allTasks.length,c:'#64748b',click:"navTo('alltasks')",k:'total'},
      {l:'New',v:newTasks.length,c:'#94a3b8',click:"navTo('alltasks','New')",k:'newT'},
      {l:'In Progress',v:inProg.length,c:'#2563eb',click:"navTo('alltasks','In Progress')",k:'inProgress'},
      {l:'Review',v:pendingRev.length,c:'#7c3aed',click:"navTo('toreview')",k:'review'},
      {l:'Done',v:doneTasks.length,c:'#15803d',click:"navTo('alltasks','Done')",k:'done'},
      {l:'Rejected',v:rejected.length,c:'#dc2626',click:"navTo('alltasks','Rejected')",k:'rejected'},
      {l:'Overdue',v:overdue.length,c:overdue.length?'#dc2626':'#15803d',click:"navTo('alltasks','Overdue')",k:'overdueCount',invert:true},
      {l:'Done/7d',v:recentDone,c:'#0891b2',click:"navTo('alltasks','Done')",k:null},
    ].map(({l,v,c,click,k,invert})=>`<div onclick="${click}" style="background:var(--s);border:1px solid var(--bd);border-top:3px solid ${c};border-radius:9px;padding:11px 8px;cursor:pointer;text-align:center;transition:box-shadow .15s" onmouseenter="this.style.boxShadow='var(--shmd)'" onmouseleave="this.style.boxShadow=''">
      <div style="font-size:22px;font-weight:800;color:${c};line-height:1;margin-bottom:3px">${v}</div>
      <div style="font-size:10px;font-weight:600;color:var(--tx3);margin-bottom:4px">${l}</div>
      <div style="min-height:16px">${k?dchip(priorSnap,k,v,!!invert):''}</div>
    </div>`).join('')}
  </div>`;

  // ROW 3 data prep
  const last30_d=new Date(now); last30_d.setDate(now.getDate()-30);
  const last30Done=doneTasks.filter(t=>t.tsReviewed&&new Date(t.tsReviewed)>=last30_d).length;
  const last30Created=allTasks.filter(t=>t.tsCreated&&new Date(t.tsCreated)>=last30_d).length;
  const todayDone=doneTasks.filter(t=>t.tsReviewed&&localDateStr(new Date(t.tsReviewed))===todayStr).length;
  const todayCreated=allTasks.filter(t=>t.tsCreated&&localDateStr(new Date(t.tsCreated))===todayStr).length;
  const day7=Array.from({length:7},(_,i)=>{
    const d=new Date(now);d.setDate(d.getDate()-(6-i));
    const ds=localDateStr(d);
    const label=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][d.getDay()];
    const created=allTasks.filter(t=>t.tsCreated&&localDateStr(new Date(t.tsCreated))===ds).length;
    const done=doneTasks.filter(t=>t.tsReviewed&&localDateStr(new Date(t.tsReviewed))===ds).length;
    return{ds,label,created,done,isToday:ds===todayStr};
  });
  const maxBar=Math.max(...day7.map(d=>Math.max(d.created,d.done)),1);
  // "Needs reminding" — the three signals the old client-side auto-reminder
  // used to check itself (not opened, stuck in progress, overdue), now
  // just surfaced here so an admin can review and fire a manual 🔔 Remind
  // with one click instead of a background job doing it silently.
  // No cap here on purpose — the card scrolls instead of hiding items.
  const needsRemindingRaw=[];
  activeTasks.forEach(t=>{
    if(t.status==='New'&&t.tsCreated&&!t.tsOpened&&(Date.now()-new Date(t.tsCreated))>=2*3600000){
      needsRemindingRaw.push({t,reason:'Not opened',hrs:Math.floor((Date.now()-new Date(t.tsCreated))/3600000)});
    } else if(t.status==='In Progress'&&t.tsStarted&&(Date.now()-new Date(t.tsStarted))>=12*3600000){
      needsRemindingRaw.push({t,reason:'No update',hrs:Math.floor((Date.now()-new Date(t.tsStarted))/3600000)});
    } else if(getDueStatus(t).key==='overdue'){
      needsRemindingRaw.push({t,reason:'Overdue',hrs:null});
    }
  });
  const needsReminding=needsRemindingRaw.sort((a,b)=>(b.hrs||999)-(a.hrs||999));
  const todayTests=DB.testSchedules.filter(s=>s.day_of_week===todayDow&&s.active!==false);
  const todayTestsDone2=DB.testSessions.filter(s=>s.test_date===todayStr&&s.status==='Completed');
  const weekStart7=new Date(now);weekStart7.setDate(now.getDate()-6);
  const weekMemberScores=DB.team.filter(m=>!isAdmin()||m.access!=='Admin').filter(m=>m.access!=='Admin'&&!FULL.includes(m.name)&&!AROLES.includes(m.role)).map(m=>{
    const mt=allTasks.filter(t=>t.assignedTo===m.id||t.assignees?.includes(m.id));
    const doneW=doneTasks.filter(t=>t.assignedTo===m.id&&t.tsReviewed&&new Date(t.tsReviewed)>=weekStart7).length;
    const overdueW=mt.filter(t=>getDueStatus(t).key==='overdue').length;
    const rejW=mt.filter(t=>t.status==='Rejected').length;
    const active=mt.filter(t=>!['Done','Cancelled'].includes(t.status)).length;
    return{m,doneW,overdueW,rejW,active,score:(doneW*3)-(overdueW*2)-rejW};
  }).filter(x=>x.active>0||x.doneW>0);
  const sortedW=[...weekMemberScores].sort((a,b)=>b.score-a.score);
  const bestW=sortedW[0];
  const worstW=sortedW[sortedW.length-1];

  // ROW 3 (NEW): Velocity + Today + This Week — 3 columns
  h+=`<div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:10px;margin-bottom:14px">

    <!-- VELOCITY -->
    <div class="card" style="min-width:0">
      <div class="ct"><span class="ct-t">⚡ Velocity</span></div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-bottom:12px">
        <div onclick="window._navF='All';window._navDay='today';navTo('alltasks')" style="background:#2563eb11;border:1px solid #2563eb22;border-radius:9px;padding:10px;text-align:center;cursor:pointer" onmouseenter="this.style.boxShadow='var(--shmd)'" onmouseleave="this.style.boxShadow=''">
          <div style="font-size:9px;font-weight:700;color:#2563eb;text-transform:uppercase;margin-bottom:3px">Created Today</div>
          <div style="font-size:26px;font-weight:800;color:#2563eb;line-height:1">${todayCreated}</div>
        </div>
        <div onclick="window._navF='Done';window._navDay='today';navTo('alltasks')" style="background:#15803d11;border:1px solid #15803d22;border-radius:9px;padding:10px;text-align:center;cursor:pointer" onmouseenter="this.style.boxShadow='var(--shmd)'" onmouseleave="this.style.boxShadow=''">
          <div style="font-size:9px;font-weight:700;color:#15803d;text-transform:uppercase;margin-bottom:3px">Done Today</div>
          <div style="font-size:26px;font-weight:800;color:#15803d;line-height:1">${todayDone}</div>
        </div>
        <div onclick="window._navF='Done';window._navDay='month';navTo('alltasks')" style="background:#7c3aed11;border:1px solid #7c3aed22;border-radius:9px;padding:10px;text-align:center;cursor:pointer" onmouseenter="this.style.boxShadow='var(--shmd)'" onmouseleave="this.style.boxShadow=''">
          <div style="font-size:9px;font-weight:700;color:#7c3aed;text-transform:uppercase;margin-bottom:3px">Done (30d)</div>
          <div style="font-size:26px;font-weight:800;color:#7c3aed;line-height:1">${last30Done}</div>
        </div>
      </div>
      <div style="font-size:10px;font-weight:700;color:var(--tx3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px">Last 7 Days</div>
      <div style="display:flex;align-items:flex-end;gap:4px;height:52px;margin-bottom:4px">
        ${day7.map(d=>`<div style="flex:1;display:flex;flex-direction:column;align-items:center;height:100%;justify-content:flex-end;gap:1px">
          <div title="Created: ${d.created}" style="width:100%;background:#2563eb${d.isToday?'':'66'};border-radius:2px 2px 0 0;height:${Math.round(d.created/maxBar*48)+2}px;min-height:${d.created?2:1}px"></div>
          <div title="Done: ${d.done}" style="width:100%;background:#15803d${d.isToday?'':'66'};border-radius:2px 2px 0 0;height:${Math.round(d.done/maxBar*48)+2}px;min-height:${d.done?2:1}px"></div>
        </div>`).join('')}
      </div>
      <div style="display:flex;gap:4px;margin-bottom:8px">
        ${day7.map(d=>`<div style="flex:1;text-align:center;font-size:9px;font-weight:${d.isToday?800:500};color:${d.isToday?'var(--ac)':'var(--tx3)'}">${d.label}</div>`).join('')}
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;padding-top:7px;border-top:1px solid var(--bd)">
        <div style="display:flex;gap:10px">
          <span style="display:flex;align-items:center;gap:4px;font-size:10px;color:var(--tx3)"><span style="width:8px;height:8px;background:#2563eb;border-radius:2px;display:inline-block"></span>Created</span>
          <span style="display:flex;align-items:center;gap:4px;font-size:10px;color:var(--tx3)"><span style="width:8px;height:8px;background:#15803d;border-radius:2px;display:inline-block"></span>Done</span>
        </div>
        <span onclick="window._navF='Done';window._navDay='month';navTo('alltasks')" style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;cursor:pointer;background:${last30Created>last30Done?'#fef2f2':'#f0fdf4'};color:${last30Created>last30Done?'#dc2626':'#15803d'};border:1px solid ${last30Created>last30Done?'#fca5a5':'#86efac'}">
          ${last30Created>last30Done?'▲ +':'▼ -'}${Math.abs(last30Created-last30Done)} net (30d) →
        </span>
      </div>
    </div>

    <!-- TODAY / UPCOMING -->
    <div class="card" style="min-width:0">
      <div class="ct"><span class="ct-t">📅 Today & Upcoming</span><span style="font-size:10px;color:var(--tx3)">${new Date().toLocaleDateString('en',{weekday:'short',day:'numeric',month:'short'})}</span></div>
      <div style="display:flex;gap:2px;margin-bottom:10px;padding:3px;background:var(--s2);border-radius:8px;width:fit-content">
        <div id="dash-today-tab" onclick="switchDashDayTab('today')" style="padding:4px 12px;font-size:11px;font-weight:700;cursor:pointer;border-radius:6px;background:var(--s);color:var(--tx);box-shadow:var(--sh)">Today</div>
        <div id="dash-upcoming-tab" onclick="switchDashDayTab('upcoming')" style="padding:4px 12px;font-size:11px;font-weight:700;cursor:pointer;border-radius:6px;color:var(--tx2)">Upcoming 10d</div>
      </div>
      <div id="dash-today-pane">
        ${todayMeetings.length?todayMeetings.slice(0,3).map(m=>`<div onclick="openMeetingDetail('${m.id}')" style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid var(--bd);cursor:pointer">
          <div style="min-width:34px;text-align:center;flex-shrink:0;font-size:11px;font-weight:900;color:var(--ac)">${(m.meeting_time||'—').slice(0,5)}</div>
          <div style="flex:1;min-width:0">
            <div style="font-size:12px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">📅 ${esc(m.title)}</div>
            <div style="font-size:10px;color:var(--tx3)">${m.duration_minutes||60}min · ${m.meeting_type||''}</div>
          </div>
        </div>`).join(''):''}
        ${todayTests.length?todayTests.map(s=>{const op2=[...DB.operators,...DB.companies].find(o=>o.id===s.operator_id);const done2=todayTestsDone2.find(ts=>ts.operator_id===s.operator_id);return`<div style="display:flex;align-items:center;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--bd)">
          <div style="font-size:11px;font-weight:700">🧪 ${op2?.name||'Test'}</div>
          <span style="background:${done2?'#f0fdf4':'#fffbeb'};color:${done2?'#15803d':'#d97706'};border:1px solid ${done2?'#bbf7d0':'#fde68a'};font-size:9px;font-weight:700;padding:2px 7px;border-radius:20px">${done2?'✓':'Pending'}</span>
        </div>`;}).join(''):''}
        ${!todayMeetings.length&&!todayTests.length?`<div style="text-align:center;padding:16px 0"><div style="font-size:20px;margin-bottom:5px">✅</div><div style="font-size:11px;color:var(--tx3)">Nothing scheduled today</div></div>`:''}
      </div>
      <div id="dash-upcoming-pane" style="display:none">
        ${(()=>{
          const now10=new Date(); now10.setDate(now10.getDate()+10);
          const todayS=localDateStr();
          const endS=localDateStr(now10);
          const items=[];
          // Upcoming meetings
          DB.meetings.filter(m=>m.meeting_date>todayS&&m.meeting_date<=endS&&!['Completed','Cancelled'].includes(m.status)&&(m.created_by===CU.name||m.invitees?.includes(CU.name)||isAdmin()))
            .forEach(m=>items.push({date:m.meeting_date,icon:'📅',label:m.title,sub:m.meeting_time+(m.duration_minutes?' · '+m.duration_minutes+'min':''),click:`openMeetingDetail('${m.id}')`}));
          // Tasks due in next 10 days
          allTasks.filter(t=>t.due&&t.due>todayS&&t.due<=endS&&!['Done','Cancelled'].includes(t.status))
            .forEach(t=>items.push({date:t.due,icon:'📋',label:t.title,sub:(mn(t.assignedTo)||'Unassigned')+' · '+t.status,click:`openTask('${t.id}')`}));
          items.sort((a,b)=>a.date.localeCompare(b.date));
          if(!items.length)return`<div style="text-align:center;padding:16px 0;font-size:11px;color:var(--tx3)">Nothing coming up in the next 10 days</div>`;
          let lastDate='';
          return items.map(it=>{
            let dh='';
            if(it.date!==lastDate){
              lastDate=it.date;
              const dObj=new Date(it.date+'T00:00:00');
              const dLabel=dObj.toLocaleDateString('en',{weekday:'short',day:'numeric',month:'short'});
              dh=`<div style="font-size:10px;font-weight:800;color:var(--ac);text-transform:uppercase;letter-spacing:.06em;padding:6px 0 2px;margin-top:4px">${dLabel}</div>`;
            }
            return dh+`<div onclick="${it.click}" style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--bd);cursor:pointer">
              <span style="font-size:13px;flex-shrink:0">${it.icon}</span>
              <div style="flex:1;min-width:0">
                <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${it.label}</div>
                <div style="font-size:10px;color:var(--tx3)">${it.sub}</div>
              </div>
            </div>`;
          }).join('');
        })()}
      </div>
    </div>

    <!-- THIS WEEK -->
    <div class="card" style="min-width:0">
      <div class="ct"><span class="ct-t">⭐ This Week</span></div>
      ${weekMemberScores.length>=2?`
        <div onclick="openMemberDetail('${bestW.m.id}')" style="display:flex;align-items:center;gap:9px;padding:8px 10px;background:#f0fdf4;border:1px solid #86efac;border-radius:9px;cursor:pointer;margin-bottom:7px">
          <span style="width:30px;height:30px;border-radius:50%;background:${bestW.m.color};display:inline-flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:#fff;flex-shrink:0">${bestW.m.av}</span>
          <div style="flex:1;min-width:0">
            <div style="font-size:10px;font-weight:800;color:#15803d;text-transform:uppercase;letter-spacing:.05em">🏆 Best</div>
            <div style="font-size:12px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(bestW.m.name)}</div>
            <div style="font-size:10px;color:#15803d">${bestW.doneW} done</div>
          </div>
          <div style="font-size:18px;font-weight:800;color:#15803d;flex-shrink:0">${bestW.score>0?'+':''}${bestW.score}</div>
        </div>
        <div onclick="openMemberDetail('${worstW.m.id}')" style="display:flex;align-items:center;gap:9px;padding:8px 10px;background:#fef2f2;border:1px solid #fca5a5;border-radius:9px;cursor:pointer">
          <span style="width:30px;height:30px;border-radius:50%;background:${worstW.m.color};display:inline-flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:#fff;flex-shrink:0">${worstW.m.av}</span>
          <div style="flex:1;min-width:0">
            <div style="font-size:10px;font-weight:800;color:#dc2626;text-transform:uppercase;letter-spacing:.05em">⚠ Focus</div>
            <div style="font-size:12px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(worstW.m.name)}</div>
            <div style="font-size:10px;color:#dc2626">${worstW.overdueW>0?worstW.overdueW+' overdue':''}${worstW.doneW===0?' 0 done':''}</div>
          </div>
          <div style="font-size:18px;font-weight:800;color:#dc2626;flex-shrink:0">${worstW.score>0?'+':''}${worstW.score}</div>
        </div>
      `:`<div style="padding:16px 0;text-align:center;font-size:12px;color:var(--tx3)">Not enough data</div>`}
    </div>
  </div>`;

  // NEEDS REMINDING — full-width row on its own so nothing gets truncated.
  // One-tap manual reminder, sends push even if the member's app/tab is
  // closed (goes through the same push pipeline as every other notification).
  h+=`<div class="card" style="margin-bottom:14px">
    <div class="ct"><span class="ct-t">🔔 Needs Reminding</span><span style="font-size:10px;color:var(--tx3)">${needsReminding.length}</span></div>
    ${needsReminding.length===0?`<div style="padding:16px 0;text-align:center;font-size:12px;color:var(--g);font-weight:600">✓ Nothing to remind</div>`:
      `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:8px;max-height:420px;overflow-y:auto;padding-right:2px">
      ${needsReminding.map(({t,reason,hrs})=>{
        const rc=reason==='Overdue'?'#dc2626':reason==='No update'?'#d97706':'#2563eb';
        // How many times — and when last — this task has already been reminded on.
        const remHist=(DB.reminders||[]).filter(r=>r.taskId===t.id).sort((a,b)=>new Date(b.at||0)-new Date(a.at||0));
        const remCount=remHist.length;
        const remLast=remHist[0];
        return`<div style="display:flex;align-items:center;gap:8px;padding:8px;background:var(--s2);border:1px solid var(--bd);border-radius:8px">
        <span onclick="openTask('${t.id}')" title="${reason==='No update'?'In Progress with no update':reason==='Not opened'?'Assigned but never opened':'Past its due date'}" style="cursor:pointer;font-size:9px;font-weight:800;color:${rc};background:${rc}15;border:1px solid ${rc}30;padding:2px 7px;border-radius:20px;flex-shrink:0;white-space:nowrap">${reason}${hrs?' '+hrs+'h':''}</span>
        <div onclick="openTask('${t.id}')" style="flex:1;overflow:hidden;min-width:0;cursor:pointer">
          <div style="font-size:11px;font-weight:600;white-space:normal;word-break:break-word;line-height:1.3">${esc(t.title)}</div>
          <div style="font-size:10px;color:var(--tx3);margin-top:2px">${mn(t.assignedTo)||'—'}</div>
          ${remCount?`<div style="font-size:10px;color:var(--ac);margin-top:2px;font-weight:600">🔔 Reminded ${remCount}× · last ${fr(remLast.at)}</div>`:`<div style="font-size:10px;color:var(--tx3);margin-top:2px">Not reminded yet</div>`}
        </div>
        <button onclick="event.stopPropagation();reqRemind('${t.id}')" title="Send reminder" style="flex-shrink:0;padding:4px 10px;background:var(--ac);color:#fff;border:none;border-radius:20px;font-size:10px;font-weight:700;cursor:pointer;white-space:nowrap">🔔 Remind</button>
      </div>`;}).join('')}
      </div>`}
  </div>`;

  // ROW 4: Recent Activity + Priority Risk + Team Load — 3 columns
  const teamLoad=DB.team.map(m=>{
    const mt2=activeTasks.filter(t=>t.assignedTo===m.id||t.assignees?.includes(m.id));
    const criticalL=mt2.filter(t=>t.priority==='Critical').length;
    const highL=mt2.filter(t=>t.priority==='High').length;
    const overdueL=mt2.filter(t=>getDueStatus(t).key==='overdue').length;
    return{m,count:mt2.length,criticalL,highL,overdueL};
  }).filter(x=>x.count>0).sort((a,b)=>b.count-a.count);
  const maxLoad=Math.max(...teamLoad.map(x=>x.count),1);

  h+=`<div style="display:grid;grid-template-columns:1.1fr 1fr 1fr;gap:10px;margin-bottom:14px">

    <!-- RECENT ACTIVITY — rich who-did-what feed -->
    <div class="card" style="min-width:0">
      <div class="ct"><span class="ct-t">🕐 Recent Activity</span></div>
      <div style="max-height:360px;overflow-y:auto;padding-right:2px">
      ${(()=>{
        const events=[];
        const memberColor=(name)=>{const m=DB.team.find(x=>x.name===name||(x.name||'').toLowerCase()===(name||'').toLowerCase());return m?m.color:'#64748b';};
        const memberAv=(name)=>{const m=DB.team.find(x=>x.name===name||(x.name||'').toLowerCase()===(name||'').toLowerCase());return m?m.av:(name||'?')[0].toUpperCase();};
        const avatar=(name,size=20)=>`<span style="width:${size}px;height:${size}px;border-radius:50%;background:${memberColor(name)};display:inline-flex;align-items:center;justify-content:center;font-size:${Math.round(size*.38)}px;color:#fff;font-weight:800;flex-shrink:0">${memberAv(name)}</span>`;

        // ── From syslog (task actions, logins, reminders) ──
        syslog.slice(0,60).forEach(e=>{
          let icon='📋',color='#64748b',text='',targetId=null,targetType=null;
          const a=esc(e.actor||'');
          switch(e.action){
            case'Login': icon='🔐';color='#2563eb';text=`<strong>${a}</strong> logged in`;break;
            case'Task Created': icon='➕';color='#2563eb';text=`<strong>${a}</strong> created <em>${esc(e.event?.replace('Task created: ',''))}</em>`;break;
            case'Task Submitted': icon='📤';color='#7c3aed';text=`<strong>${a}</strong> submitted <em>${esc(e.event?.match(/"([^"]+)"/)?.[1]||'')}</em> for review`;break;
            case'Approved': icon='✅';color='#15803d';text=`<strong>${a}</strong> approved <em>${esc(e.event?.match(/"([^"]+)"/)?.[1]||'')}</em>`;break;
            case'Rejected': icon='❌';color='#dc2626';text=`<strong>${a}</strong> rejected <em>${esc(e.event?.match(/"([^"]+)"/)?.[1]||'')}</em>`;break;
            case'Re-Estimated': icon='⏱';color='#d97706';text=`<strong>${a}</strong> re-estimated <em>${esc(e.event?.match(/"([^"]+)"/)?.[1]||'')}</em>`;break;
            case'Help Requested': icon='🤝';color='#ea580c';text=`<strong>${a}</strong> requested help — ${esc(e.event?.replace('Help requested:','').trim())}`;break;
            case'Reminder Sent': icon='🔔';color='#7c3aed';text=`<strong>${a}</strong> reminded ${esc(e.event?.match(/reminded (.+?) about/)?.[1]||'someone')}`;break;
            case'Delete': icon='🗑';color='#dc2626';text=`<strong>${a}</strong> deleted ${esc(e.event||'an item')}`;break;
            default: icon='📋';color='#64748b';text=`<strong>${a}</strong> — ${esc(e.action)}`;
          }
          if(text) events.push({ts:e.at,icon,color,text,targetId,targetType,actor:a});
        });

        // ── Task timeline events ───────────────────────────
        allTasks.forEach(t=>{
          (t.timeline||[]).forEach(ev=>{
            let icon='📋',color='#64748b',text='';
            if(ev.type==='help_requested'){icon='🤝';color='#ea580c';text=`<strong>${esc(ev.by)}</strong> requested help from ${esc(ev.helpMember||'?')} on <em>${esc(t.title)}</em>`;}
            else if(ev.type==='help_received'){icon='✅';color='#15803d';text=`<strong>${esc(ev.by)}</strong> accepted help from ${esc(ev.helperName||'?')} — <em>${esc(t.title)}</em> continues`;}
            else{icon='📋';color='#64748b';text=`<strong>${esc(ev.by||'?')}</strong> — ${esc(ev.event)} on <em>${esc(t.title)}</em>`;}
            events.push({ts:ev.at,icon,color,text,targetId:t.id,targetType:'task',actor:ev.by||''});
          });
          // Task status changes derived from timestamps
          if(t.tsStarted) events.push({ts:t.tsStarted,icon:'▶',color:'#2563eb',text:`<strong>${esc(mn(t.assignedTo)||'?')}</strong> started <em>${esc(t.title)}</em>`,targetId:t.id,targetType:'task',actor:mn(t.assignedTo)||''});
          if(t.tsSubmitted) events.push({ts:t.tsSubmitted,icon:'📤',color:'#7c3aed',text:`<strong>${esc(mn(t.assignedTo)||'?')}</strong> submitted <em>${esc(t.title)}</em> for review`,targetId:t.id,targetType:'task',actor:mn(t.assignedTo)||''});
          if(t.tsReviewed&&t.status==='Done') events.push({ts:t.tsReviewed,icon:'✅',color:'#15803d',text:`<strong>${esc(mn(t.reviewer)||'Admin')}</strong> approved <em>${esc(t.title)}</em>`,targetId:t.id,targetType:'task',actor:mn(t.reviewer)||''});
        });

        // ── Meetings ──────────────────────────────────────
        DB.meetings.forEach(m=>{
          const ts=m.ended_at||m.created_at||m.meeting_date;
          const creator=m.created_by||'?';
          const status=m.status;
          const icon=status==='Completed'?'✅':status==='Cancelled'?'❌':'📅';
          const color=status==='Completed'?'#15803d':status==='Cancelled'?'#dc2626':'#2563eb';
          const label=status==='Completed'?'completed meeting':'scheduled meeting';
          events.push({ts,icon,color,text:`<strong>${esc(creator)}</strong> ${label} <em>${esc(m.title)}</em>`,targetId:m.id,targetType:'meeting',actor:creator});
          // Attendance events
          Object.entries(m.attendance||{}).forEach(([name,status])=>{
            if(status==='present') events.push({ts:m.ended_at||m.meeting_date,icon:'👋',color:'#2563eb',text:`<strong>${esc(name)}</strong> attended <em>${esc(m.title)}</em>`,targetId:m.id,targetType:'meeting',actor:name});
          });
        });

        // ── Reminders from DB ─────────────────────────────
        (DB.reminders||[]).forEach(r=>{
          events.push({ts:r.at,icon:'🔔',color:'#7c3aed',text:`<strong>${esc(r.fromName||'?')}</strong> reminded <strong>${esc(r.toName||'?')}</strong>${r.taskTitle?' about <em>'+esc(r.taskTitle)+'</em>':''}`,targetId:r.taskId,targetType:'task',actor:r.fromName||''});
        });

        // Sort by timestamp, take top 12
        events.sort((a,b)=>new Date(b.ts||0)-new Date(a.ts||0));
        const top=events.filter(e=>e.ts).slice(0,12);

        if(!top.length) return`<div style="padding:16px 0;text-align:center;font-size:12px;color:var(--tx3)">No activity yet</div>`;

        return top.map(ev=>`<div onclick="${ev.targetType==='task'&&ev.targetId?`openTask('${ev.targetId}')`:ev.targetType==='meeting'&&ev.targetId?`openMeetingDetail('${ev.targetId}')`:''}" style="display:flex;align-items:flex-start;gap:8px;padding:6px 0;border-bottom:1px solid var(--bd);cursor:${ev.targetId?'pointer':'default'}">
          <span style="font-size:13px;flex-shrink:0;line-height:1.5">${ev.icon}</span>
          <div style="flex:1;overflow:hidden;min-width:0">
            <div style="font-size:12px;color:var(--tx);line-height:1.4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${ev.text}</div>
            <div style="font-size:10px;color:var(--tx3);margin-top:1px">${fr(ev.ts)}</div>
          </div>
        </div>`).join('');
      })()}
      </div>
    </div>

    <!-- PRIORITY RISK -->
    <div class="card" style="min-width:0">
      <div class="ct"><span class="ct-t">🎯 Priority Risk</span></div>
      ${svgDonutChart([
        {label:'Critical',color:'#dc2626',v:activeTasks.filter(t=>t.priority==='Critical').length},
        {label:'High',color:'#c2410c',v:activeTasks.filter(t=>t.priority==='High').length},
        {label:'Medium',color:'#b45309',v:activeTasks.filter(t=>t.priority==='Medium').length},
        {label:'Low',color:'#15803d',v:activeTasks.filter(t=>t.priority==='Low').length}
      ])}
      ${(()=>{
        const crit=activeTasks.filter(t=>t.priority==='Critical').length;
        const high=activeTasks.filter(t=>t.priority==='High').length;
        const med=activeTasks.filter(t=>t.priority==='Medium').length;
        const score=crit*4+high*2+med+overdue.length*3;
        const max=Math.max(score,50);
        const risk=score>=30?'Critical':score>=15?'High':score>=5?'Medium':'Low';
        const rc={Critical:'#dc2626',High:'#c2410c',Medium:'#b45309',Low:'#15803d'}[risk];
        return`<div onclick="navTo('alltasks')" style="cursor:pointer;background:var(--s2);border-radius:8px;padding:6px 9px 9px;border:1px solid var(--bd);margin-top:10px">
          <div style="font-size:10px;font-weight:700;color:var(--tx3);text-transform:uppercase;text-align:center">Overall Risk</div>
          ${riskGaugeArc(Math.min(Math.round(score/max*100),100),rc,risk,`score ${score}`)}
        </div>`;
      })()}
    </div>

    <!-- TEAM LOAD -->
    <div class="card" style="min-width:0">
      <div class="ct"><span class="ct-t">👥 Team Load</span></div>
      <div style="display:flex;flex-direction:column;gap:2px;max-height:360px;overflow-y:auto;padding-right:2px">
        ${teamLoadRows(teamLoad,maxLoad)}
      </div>
    </div>
  </div>`;

  // ROW 5: Operations (full width)
  const liveServices=DB.services.filter(s=>s.status==='Live').length;
  h+=`<div class="card" style="margin-bottom:14px">
    <div class="ct"><span class="ct-t">Operations Overview</span></div>
    <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px">
      ${[
        {icon:'📡',label:'Operators',val:DB.operators.length,sub:DB.operators.filter(o=>o.status==='Active'||!o.status).length+' active',click:"navTo('operators')"},
        {icon:'◐',label:'Services',val:DB.services.length,sub:liveServices+' live',click:"navTo('services')"},
        {icon:'◉',label:'Projects',val:DB.projects.length,sub:activeProj+' active',click:"navTo('projects')"},
        {icon:'🏢',label:'Companies',val:DB.companies.length,sub:'',click:"navTo('companies')"},
        {icon:'👥',label:'Team',val:DB.team.length,sub:membersWithTasks+' active',click:"navTo('team')"},
      ].map(({icon,label,val,sub,click})=>`<div onclick="${click}" style="background:var(--s2);border:1px solid var(--bd);border-radius:10px;padding:16px;cursor:pointer;text-align:center;transition:box-shadow .15s" onmouseenter="this.style.boxShadow='var(--shmd)'" onmouseleave="this.style.boxShadow=''">
        <div style="font-size:24px;margin-bottom:6px">${icon}</div>
        <div style="font-size:24px;font-weight:800;color:var(--tx);line-height:1;margin-bottom:3px">${val}</div>
        <div style="font-size:13px;font-weight:600;color:var(--tx2)">${label}</div>
        ${sub?`<div style="font-size:11px;color:var(--tx3);margin-top:2px">${sub}</div>`:''}
      </div>`).join('')}
    </div>
  </div>`;

  // ── EXTRA: Recent Logins (Material dashboard addition) ──
  h+=`<div id="dash-login-widget" style="margin-bottom:14px"></div>`;

  // ROW 6: Team Performance (full width)
  const teamPerf=DB.team.map(m=>{
    const mt=allTasks.filter(t=>t.assignedTo===m.id||t.assignees?.includes(m.id));
    const active=mt.filter(t=>!['Done','Cancelled'].includes(t.status)).length;
    done=mt.filter(t=>t.status==='Done').length;
    const od=mt.filter(t=>getDueStatus(t).key==='overdue').length;
    const inrev=mt.filter(t=>t.status==='Pending Review').length;
    const recent_d=mt.filter(t=>t.tsReviewed&&new Date(t.tsReviewed)>=last30_d&&t.status==='Done').length;
    const rate=mt.length?Math.round(done/mt.length*100):0;
    return{m,active,done,od,inrev,recent_d,rate,tot:mt.length};
  }).sort((a,b)=>b.active-a.active);

  h+=`<div class="card">
    <div class="ct"><span class="ct-t">Team Performance</span><span onclick="navTo('team')" style="font-size:12px;color:var(--ac);cursor:pointer;font-weight:600">View team →</span></div>
    <div class="tw"><table>
      <thead><tr><th>Member</th><th>Role</th><th>Active</th><th>Done (30d)</th><th>Overdue</th><th>Review</th><th>Rate</th><th>Load</th></tr></thead>
      <tbody>
        ${teamPerf.map(({m,active,done,od,inrev,recent_d,rate})=>`<tr class="cl" onclick="openMemberDetail('${m.id}')">
          <td><span style="display:flex;align-items:center;gap:8px">
            <span style="width:28px;height:28px;border-radius:50%;background:${m.color};display:inline-flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#fff;flex-shrink:0">${m.av}</span>
            <span style="font-size:13px;font-weight:700">${esc(m.name)}</span>
          </span></td>
          <td style="font-size:12px;color:var(--tx3)">${m.role}</td>
          <td><span style="font-size:16px;font-weight:800;color:${active>=5?'#dc2626':active>=2?'#b45309':'var(--tx)'}">${active}</span></td>
          <td style="font-size:14px;font-weight:700;color:var(--g)">${recent_d}</td>
          <td style="${od>0?'color:#dc2626;font-weight:700':'color:var(--tx3)'}">${od>0?'⚠ '+od:'—'}</td>
          <td style="${inrev>0?'color:#7c3aed;font-weight:700':'color:var(--tx3)'}">${inrev>0?inrev+'⏳':'—'}</td>
          <td><div style="display:flex;align-items:center;gap:6px">
            <div style="width:52px;height:5px;background:var(--s2);border-radius:3px;overflow:hidden">
              <div style="height:100%;width:${rate}%;background:${rate>=70?'#15803d':rate>=40?'#b45309':'#dc2626'};border-radius:3px"></div>
            </div>
            <span style="font-size:12px;font-weight:700;color:${rate>=70?'#15803d':rate>=40?'#b45309':'#dc2626'}">${rate}%</span>
          </div></td>
          <td><span style="background:${active>=5?'#fef2f2':active>=3?'#fffbeb':'#f0fdf4'};color:${active>=5?'#dc2626':active>=3?'#b45309':'#15803d'};font-size:11px;font-weight:700;padding:3px 9px;border-radius:20px;border:1px solid ${active>=5?'#fca5a5':active>=3?'#fcd34d':'#86efac'}">${active>=5?'High':active>=3?'Med':'Low'}</span></td>
        </tr>`).join('')}
      </tbody>
    </table></div>
  </div>`;



  el.innerHTML=h;
  loadDashLoginWidget();
}

async function loadDashLoginWidget(){
  const box=document.getElementById('dash-login-widget');
  if(!box) return;
  try{
    const data=await sbQ('activity_log','action=eq.Login&order=created_at.desc&limit=40');
    if(!Array.isArray(data)){ box.innerHTML=''; return; }
    const byDevice={};
    data.forEach(e=>{ (byDevice[e.device_id]=byDevice[e.device_id]||new Set()).add(e.actor_name); });
    const shared=Object.entries(byDevice).filter(([,names])=>names.size>1);
    const recent=data.slice(0,6);
    box.innerHTML=`<div class="card">
      <div class="ct"><span>🔐 Recent Logins</span></div>
      ${shared.length?`<div style="background:var(--rb);border-radius:12px;padding:10px 12px;margin-bottom:10px;font-size:11.5px;color:var(--r);font-weight:600">⚠ ${shared.length} device${shared.length>1?'s have':' has'} been used to log in as more than one account</div>`:''}
      ${recent.map(e=>{
        const m=DB.team.find(x=>x.name===e.actor_name);
        const flagged=byDevice[e.device_id]&&byDevice[e.device_id].size>1;
        return`<div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--bd)">
          ${m?`<span style="width:24px;height:24px;border-radius:50%;background:${m.color};display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:#fff;flex-shrink:0">${m.av}</span>`:'<span style="width:24px;height:24px;border-radius:50%;background:var(--s2);flex-shrink:0"></span>'}
          <span style="flex:1;font-size:12.5px;font-weight:600">${e.actor_name||'Unknown'}${flagged?' <span style="color:var(--r)" title="Device also used by another account">⚠</span>':''}</span>
          <span style="font-size:10.5px;color:var(--tx3)">${fr?fr(e.created_at):new Date(e.created_at).toLocaleString()}</span>
        </div>`;
      }).join('')}
    </div>`;
  }catch(err){ box.innerHTML=''; }
}

// ══════════════════════════════════════════════════════════════════════
// DEVICE FINGERPRINT + DATABASE-BACKED ACTIVITY LOG WIRING
// (System Log page removed — this plumbing stays because the Recent
// Logins dashboard widget and the shared-device login warning below
// both still read from the activity_log table.)
// ══════════════════════════════════════════════════════════════════════
function getDeviceId(){
  let id=localStorage.getItem('vas_device_id');
  if(!id){
    id='dev_'+Math.random().toString(36).slice(2,10)+Date.now().toString(36);
    localStorage.setItem('vas_device_id',id);
  }
  return id;
}

// Override nLog so every EXISTING logAction() call across the whole app
// (tasks, meetings, HR comms, library, backlog, logins, everything)
// also persists to the activity_log Supabase table — silently, so it
// never spams a toast if the table hasn't been created yet.
async function nLog(e){
  try{
    await fetch(`${SB_URL}/rest/v1/activity_log`,{
      method:'POST',
      headers:{...SB_HEADERS,'Prefer':'return=minimal'},
      body:JSON.stringify({
        actor_id:e.actorId||'', actor_name:e.actor||'System', actor_role:e.actorRole||'',
        action:e.action||'', event:e.event||'', target:e.target||'', details:e.details||'',
        severity:e.severity||'Info', device_id:getDeviceId(), user_agent:navigator.userAgent,
        meta:{memberId:e.memberId,memberName:e.memberName,taskId:e.taskId,taskTitle:e.taskTitle,
              projectId:e.projectId,projectName:e.projectName,serviceId:e.serviceId,serviceName:e.serviceName,
              operatorId:e.operatorId,operatorName:e.operatorName,meetingId:e.meetingId}
      })
    });
  }catch(err){ /* silent — table probably not set up yet, see SQL at bottom of this file */ }
}

// Wrap startApp (assignment, not a `function` redeclaration, so hoisting
// can't clobber the original before we capture it) to surface a warning
// if this device previously logged in as a different account.
(function(){
  const _origStartApp = startApp;
  startApp = async function(){
    const r = await _origStartApp.apply(this, arguments);
    try{
      const devId=getDeviceId();
      const prior=await sbQ('activity_log',`action=eq.Login&device_id=eq.${devId}&order=created_at.desc&limit=30`);
      if(Array.isArray(prior)){
        const others=[...new Set(prior.map(p=>p.actor_name).filter(n=>n&&n!==CU?.name))];
        if(others.length) toast(`⚠ This device previously logged in as: ${others.join(', ')}`,'bad',9000);
      }
    }catch(err){}
    return r;
  };
})();

/* ════════════════════════════════════════════════════════════════════
   ONE-TIME SUPABASE SETUP — run this once in your Supabase SQL editor
   to unlock the Recent Logins widget + device-sharing detection above.
   Nothing else in this file depends on it; everything else already works.
   ════════════════════════════════════════════════════════════════════

create table if not exists activity_log (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  actor_id text,
  actor_name text,
  actor_role text,
  action text,
  event text,
  target text,
  details text,
  severity text default 'Info',
  device_id text,
  user_agent text,
  meta jsonb default '{}'::jsonb
);

alter table activity_log enable row level security;

create policy "activity_log_select_anon" on activity_log
  for select using (true);

create policy "activity_log_insert_anon" on activity_log
  for insert with check (true);

   ════════════════════════════════════════════════════════════════════ */
