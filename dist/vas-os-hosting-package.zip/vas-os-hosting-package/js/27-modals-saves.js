// §27 ── MODALS & SAVE FUNCTIONS ────────────────────────────────────────
function openTaskModal(id, presetProjectId){
  _editId=id; const t=id?DB.tasks.find(x=>x.id===id):null;
  document.getElementById('m-task-t').textContent=t?'Edit Task':'Create Task';
  document.getElementById('tf-btn').textContent=t?'Save Changes':'Create Task';
  // Tag-style assignee picker
  initAssignPicker(t?.assignees||( t?.assignedTo?[t.assignedTo]:[] ));
  document.getElementById('tf-reviewer').innerHTML='<option value="">None</option>'+DB.team.map(m=>`<option value="${m.id}">${esc(m.name)}</option>`).join('');
  // Company dropdown (pure companies, not operators)
  document.getElementById('tf-company').innerHTML='<option value="">None</option>'+DB.companies.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');
  document.getElementById('tf-service').innerHTML='<option value="">None</option>'+DB.services.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('');
  document.getElementById('tf-operator').innerHTML='<option value="">None</option>'+[...DB.operators,...DB.companies].map(o=>`<option value="${o.id}">${esc(o.name)}</option>`).join('');
  if(document.getElementById('tf-project')) document.getElementById('tf-project').innerHTML='<option value="">None</option>'+DB.projects.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
  document.getElementById('tf-title').value=t?.title||'';
  document.getElementById('tf-priority').value=t?.priority||'High';
  document.getElementById('tf-type').value=t?.type||'Feature';
  // Tag picker handles restore via initAssignPicker above
  document.getElementById('tf-reviewer').value=t?.reviewer||'';
  document.getElementById('tf-service').value=t?.service||'';
  document.getElementById('tf-operator').value=t?.operator||'';
  document.getElementById('tf-due').value=t?.due||'';
  document.getElementById('tf-reqby').value=t?.reqBy||CU.name;
  document.getElementById('tf-desc').value=t?.desc||'';
  if(document.getElementById('tf-est')) document.getElementById('tf-est').value=t?.est||'';
  if(document.getElementById('tf-recur')) document.getElementById('tf-recur').value=t?.recur||'';
  if(document.getElementById('tf-project')) document.getElementById('tf-project').value=t?.projectId||presetProjectId||'';
  // Apply current saved dropdown lists
  try{
    const saved=JSON.parse(localStorage.getItem('vas_dropdown_lists')||'{}');
    const types=saved.taskTypes||['Feature','Bug Fix','Content','Design','Maintenance','Research','Meeting'];
    const priorities=saved.taskPriorities||['Critical','High','Medium','Low'];
    const typeEl=document.getElementById('tf-type');
    const prioEl=document.getElementById('tf-priority');
    if(typeEl){const cv=typeEl.value;typeEl.innerHTML=types.map(t=>`<option ${cv===t?'selected':''}>${t}</option>`).join('');if(types.includes(cv))typeEl.value=cv;}
    if(prioEl){const cv=prioEl.value;prioEl.innerHTML=priorities.map(p=>`<option ${cv===p?'selected':''}>${p}</option>`).join('');if(priorities.includes(cv))prioEl.value=cv;}
  }catch(e){}
  OM('m-task');
}

// Quick "same task, different name" — pre-fills the Create modal from an
// existing task so the assignee, reviewer, service, operator, company,
// project, priority and type all carry over. Title/description come along
// too as a starting point (edit as needed); due date is left blank since
// it's almost always different for a duplicate.
window.duplicateTask=(id)=>{
  const src=DB.tasks.find(t=>t.id===id);
  if(!src){toast('Task not found','bad');return;}
  openTaskModal(null, src.projectId);
  document.getElementById('tf-title').value=src.title||'';
  document.getElementById('tf-desc').value=src.desc||'';
  document.getElementById('tf-priority').value=src.priority||'High';
  document.getElementById('tf-type').value=src.type||'Feature';
  document.getElementById('tf-reviewer').value=src.reviewer||'';
  document.getElementById('tf-service').value=src.service||'';
  document.getElementById('tf-operator').value=src.operator||'';
  if(document.getElementById('tf-company')) document.getElementById('tf-company').value=src.company2||'';
  if(document.getElementById('tf-est')) document.getElementById('tf-est').value=src.est||'';
  if(document.getElementById('tf-recur')) document.getElementById('tf-recur').value=src.recur||'';
  document.getElementById('tf-reqby').value=src.reqBy||CU.name;
  initAssignPicker(src.assignees?.length?src.assignees:(src.assignedTo?[src.assignedTo]:[]));
  const titleEl=document.getElementById('tf-title');
  titleEl.focus(); titleEl.select();
  toast('Duplicated — adjust the title/description, set a due date, and save','inf',5000);
};

function openMemberModal(id){
  _editId=id; const m=id?DB.team.find(x=>x.id===id):null;
  document.getElementById('m-mbr-t').textContent=m?'Edit Team Member':'Add Team Member';
  document.getElementById('mf-btn').textContent=m?'Save Changes':'Add Member';
  document.getElementById('mf-name').value=m?.name||'';
  document.getElementById('mf-role').value=m?.role||'Content Manager';
  document.getElementById('mf-dept').value=m?.dept||'Engineering';
  document.getElementById('mf-access').value=m?.access||'Member';
  document.getElementById('mf-email').value=m?.email||'';
  // Populate employment type dropdown
  const mtEl=document.getElementById('mf-mtype');
  if(mtEl){
    const types=getMemberTypes();
    mtEl.innerHTML='<option value="">— None —</option>'+types.map(t=>`<option value="${esc(t.name)}" ${m?.memberType===t.name?'selected':''}>${esc(t.name)}</option>`).join('');
  }
  if(document.getElementById('mf-username'))document.getElementById('mf-username').value=m?.username||'';
  if(document.getElementById('mf-password'))document.getElementById('mf-password').value='';
  document.getElementById('mf-telegram').value=m?.telegram||'';
  // Individual content-access overrides — each defaults to "" (inherit
  // from employment type) unless this member already has an explicit
  // grant/deny set on their record.
  ['projects','services','library','docs','archive','comments','reminders'].forEach(perm=>{
    const el=document.getElementById('mf-perm-'+perm);
    if(el) el.value=(m?.permOverrides&&typeof m.permOverrides[perm]==='boolean')?(m.permOverrides[perm]?'grant':'deny'):'';
  });
  const autoRemEl=document.getElementById('mf-auto-rem');
  if(autoRemEl) autoRemEl.checked=m?.autoRemindersActive!==false;
  // Apply saved lists to role/dept selects
  try{
    const saved=JSON.parse(localStorage.getItem('vas_dropdown_lists')||'{}');
    const roles=saved.memberRoles||['CEO','Projects Manager','HR Manager','Super Senior Developer','Senior Developer','Front End Developer','Front End Designer','Sys Admin','Content Manager','Developer'];
    const depts=saved.memberDepartments||['Engineering','Design','Content','Management','Marketing','Finance','Other'];
    const roleEl=document.getElementById('mf-role');
    const deptEl=document.getElementById('mf-dept');
    if(roleEl){const cv=roleEl.value;roleEl.innerHTML=roles.map(r=>`<option ${cv===r?'selected':''}>${r}</option>`).join('');if(roles.includes(cv))roleEl.value=cv;}
    if(deptEl){const cv=deptEl.value;deptEl.innerHTML=depts.map(d=>`<option ${cv===d?'selected':''}>${d}</option>`).join('');if(depts.includes(cv))deptEl.value=cv;}
  }catch(e){}
  OM('m-mbr');
}

function openServiceModal(id){
  _editId=id; const s=id?DB.services.find(x=>x.id===id):null;
  document.getElementById('m-svc-t').textContent=s?'Edit Service':'Add Service';
  document.getElementById('sf-btn').textContent=s?'Save Changes':'Add Service';
  document.getElementById('sf-name').value=s?.name||'';
  if(document.getElementById('sf-type')) document.getElementById('sf-type').value=s?.service_type||'Digital';
  document.getElementById('sf-cat').value=s?.cat||'Content';
  document.getElementById('sf-status').value=s?.status||'Live';
  document.getElementById('sf-desc').value=s?.desc||'';
  // Apply current saved lists to dropdowns
  try{
    const saved=JSON.parse(localStorage.getItem('vas_dropdown_lists')||'{}');
    const types=saved.serviceTypes||['Digital','IVR','USSD','SMS'];
    const cats=saved.serviceCategories||['Content','Education','Entertainment','Gaming','Books','Other'];
    const stats=saved.serviceStatuses||['Live','In Development','Paused','Deprecated'];
    const typeEl=document.getElementById('sf-type');
    const catEl=document.getElementById('sf-cat');
    const statEl=document.getElementById('sf-status');
    if(typeEl) typeEl.innerHTML=types.map(t=>`<option value="${t}" ${(s?.service_type||'Digital')===t?'selected':''}>${t}</option>`).join('');
    if(catEl)  catEl.innerHTML=cats.map(t=>`<option value="${t}" ${(s?.cat||'')===t?'selected':''}>${t}</option>`).join('');
    if(statEl) statEl.innerHTML=stats.map(t=>`<option value="${t}" ${(s?.status||'Live')===t?'selected':''}>${t}</option>`).join('');
  }catch(e){}
  OM('m-svc');
}

function openOperatorModal(id){
  _editId=id; const o=id?DB.operators.find(x=>x.id===id):null;
  document.getElementById('m-op-t').textContent=o?'Edit Operator':'Add Operator';
  document.getElementById('of-btn').textContent=o?'Save Changes':'Add Operator';
  document.getElementById('of-name').value=o?.name||'';
  document.getElementById('of-country').value=o?.country||'Sudan';
  document.getElementById('of-status').value=o?.status||'Active';
  document.getElementById('of-contact').value=o?.contact||'';
  document.getElementById('of-email').value=o?.email||'';
  document.getElementById('of-phone').value=o?.phone||'';
  document.getElementById('of-notes').value=o?.notes||'';
  OM('m-op');
}

function openCompanyModal(id){
  _editId=id; const c=id?DB.companies.find(x=>x.id===id):null;
  document.getElementById('m-co-t').textContent=c?'Edit Company':'Add Company';
  document.getElementById('cf-btn').textContent=c?'Save Changes':'Add Company';
  document.getElementById('cf-name').value=c?.name||'';
  document.getElementById('cf-type').value=c?.type||'Partner';
  document.getElementById('cf-country').value=c?.country||'Sudan';
  document.getElementById('cf-contact').value=c?.contact||'';
  document.getElementById('cf-email').value=c?.email||'';
  document.getElementById('cf-notes').value=c?.notes||'';
  OM('m-co');
}

function openDocModal(id){
  _editId=id; const d=id?DB.docs.find(x=>x.id===id):null;
  document.getElementById('m-doc-t').textContent=d?'Edit Document':'Add Documentation';
  document.getElementById('df-btn').textContent=d?'Save Changes':'Save Document';
  document.getElementById('df-title').value=d?.title||'';
  document.getElementById('df-type').value=d?.type||'Task Documentation';
  document.getElementById('df-status').value=d?.status||'Published';
  document.getElementById('df-content').value=d?.content||'';
  OM('m-doc');
}

function openTodoModal(id){
  _editId=id; const td=id?DB.todos.find(x=>x.id===id):null;
  document.getElementById('m-todo-t').textContent=td?'Edit Todo':'Add Todo';
  document.getElementById('todo-btn').textContent=td?'Save Changes':'Save Todo';
  document.getElementById('todo-title').value=td?.title||'';
  document.getElementById('todo-prio').value=td?.priority||'High';
  document.getElementById('todo-due').value=td?.due||'';
  document.getElementById('todo-reminder').value=td?.reminder?td.reminder.slice(0,16):'';
  document.getElementById('todo-notes').value=td?.notes||'';
  OM('m-todo');
}

// ══════════════════════════════════════════════════════
// FORM SAVES
// ══════════════════════════════════════════════════════
window.saveTask=async()=>{
  const title=document.getElementById('tf-title').value.trim();
  if(!title){toast('Task title required','bad');return;}
  if(_editId){
    const t=DB.tasks.find(x=>x.id===_editId);if(!t)return;
    t.title=title; t.priority=document.getElementById('tf-priority').value; t.type=document.getElementById('tf-type').value;
    const newAssignees=getSelectedAssignees();
    if(newAssignees.length){t.assignees=newAssignees;t.assignedTo=newAssignees[0];t.tsAssigned=now();}
    t.reviewer=document.getElementById('tf-reviewer').value; t.service=document.getElementById('tf-service').value;
    t.operator=document.getElementById('tf-operator').value;
    t.company2=document.getElementById('tf-company').value||null;
    t.link=document.getElementById('tf-link').value||'';
    t.projectId=document.getElementById('tf-project')?.value||null;
    t.due=document.getElementById('tf-due').value;
    t.reqBy=document.getElementById('tf-reqby').value; t.desc=document.getElementById('tf-desc').value;
    logAction('Task Updated',`${esc(CU.name)} updated "${title}"`,'Info',title,'');
    await nUpdateTask(t);
    CM('m-task'); toast('Task updated ✓','ok');
    if(page==='alltasks'||page==='mytasks')nav(page,document.querySelector('.ni.on'));
  } else {
    const assignees=getSelectedAssignees();
    const assignedTo2=assignees[0]||'';
    const t={id:'t'+gid(),title,status:'New',priority:document.getElementById('tf-priority').value,type:document.getElementById('tf-type').value,
      assignedTo:assignedTo2,assignees,
      reviewer:document.getElementById('tf-reviewer').value,
      service:document.getElementById('tf-service').value,
      operator:document.getElementById('tf-operator').value,
      company2:document.getElementById('tf-company').value||null,
      link:document.getElementById('tf-link').value||'',
      projectId:document.getElementById('tf-project')?.value||null,
      reqBy:document.getElementById('tf-reqby').value,due:document.getElementById('tf-due').value,
      est:parseFloat(document.getElementById('tf-est')?.value)||null,
      recur:document.getElementById('tf-recur')?.value||null,
      actual:null,what:'',tech:'',rejReason:'',createdBy:CU?.name||'',tsCreated:now(),tsAssigned:assignedTo2?now():null,tsOpened:null,tsStarted:null,tsSubmitted:null,tsReviewed:null,tsArchived:null,rejections:[],
      desc:document.getElementById('tf-desc').value,respH:null,workH:null,revH:null,cycleH:null};
    DB.tasks.unshift(t);
    const ass=DB.team.find(m=>m.id===assignedTo2);
    logAction('Task Created',`${esc(CU.name)} created "${title}" → ${ass?.name||'?'}`,'Success',title,'');
    const r=await nCreateTask(t,t.id); if(r?.id) t.id=r.id; // use Supabase UUID
    // If converted from a Todo, remove it
    if(window._pendingTodoId){
      const tid=window._pendingTodoId; window._pendingTodoId=null;
      DB.todos=DB.todos.filter(x=>x.id!==tid);
      try{await sbDelete('todos',tid);}catch(e){}
    }
    // Notify assignee
    // Notify all assignees — in-app + Telegram
    const allAssigneeIds=t.assignees?.length?t.assignees:[t.assignedTo].filter(Boolean);
    allAssigneeIds.forEach(aid=>{
      const am=DB.team.find(m=>m.id===aid);
      if(am&&!sameName(am.name,CU?.name)){
        sendNotif(am.name,`New task assigned: "${title}" — ${t.priority} priority`,"Task Assigned",title);
        notifyTG(aid,'task_assigned',{title,priority:t.priority,due:t.due||'Not set',desc:t.desc||'',link:appLink('task-'+t.id)});
      }
    });
    // Notify reviewer — in-app + Telegram
    const rev=DB.team.find(m=>m.id===t.reviewer);
    if(rev&&!sameName(rev.name,CU?.name)&&!sameName(rev.name,ass?.name)){
      sendNotif(rev.name,`You are reviewer for new task: "${title}" (assigned to ${ass?.name||'?'})`,'Task Assigned',title);
      notifyTG(rev.id,'review_requested',{title,priority:t.priority,link:appLink('task-'+t.id)});
    }
    // Notify all admins
    notifyAdmins(`${CU.name} created new task: "${title}" → assigned to ${ass?.name||'unassigned'}`,'Task Assigned',title);
    CM('m-task'); updateBadges(); toast('Task created — member notified ✓','ok');
    if(page==='alltasks'||page==='dash')nav(page,document.querySelector('.ni.on'));
    // Copy task link to clipboard after creation
    try{const tLink=window.location.href.split('#')[0]+'#task-'+t.id;navigator.clipboard.writeText(tLink).then(()=>toast('Task link copied ✓','ok')).catch(()=>{});}catch(e){}
  }
};

// One-click test task generator — creates one real task per selected
// member, through the exact same create path as the normal "+ New Task"
// form (DB write, in-app notif, push/Telegram, admin notif, syslog).
// This is a genuine end-to-end test of notification delivery and task
// behavior, not a simulated preview — each task behaves completely
// normally and can be started/submitted/approved/deleted like any other.
window.createTestTasksForMembers=async()=>{
  const ids=[...document.querySelectorAll('.test-task-member:checked')].map(c=>c.value);
  if(!ids.length){toast('Select at least one member','bad');return;}
  const due=document.getElementById('test-task-due')?.value||'';
  const stamp=new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
  let created=0;
  for(const aid of ids){
    const ass=DB.team.find(m=>m.id===aid);
    if(!ass) continue;
    const title=`🧪 Test Task — ${ass.name} (${stamp})`;
    const t={id:'t'+gid(),title,status:'New',priority:'Low',type:'Maintenance',
      assignedTo:aid,assignees:[aid],
      reviewer:CU?.id||'',
      service:'',operator:'',company2:null,link:'',projectId:null,
      reqBy:CU?.name||'',due,est:null,recur:null,
      actual:null,what:'',tech:'',rejReason:'',createdBy:CU?.name||'',tsCreated:now(),tsAssigned:now(),tsOpened:null,tsStarted:null,tsSubmitted:null,tsReviewed:null,tsArchived:null,rejections:[],
      desc:'Test task — created to verify notification delivery and app behavior. Safe to complete or delete.',respH:null,workH:null,revH:null,cycleH:null};
    DB.tasks.unshift(t);
    logAction('Task Created',`${esc(CU.name)} created "${title}" → ${ass.name}`,'Success',title,'');
    const r=await nCreateTask(t,t.id); if(r?.id) t.id=r.id;
    if(!sameName(ass.name,CU?.name)){
      sendNotif(ass.name,`New task assigned: "${title}" — Low priority`,'Task Assigned',title);
      notifyTG(aid,'task_assigned',{title,priority:'Low',due:due||'Not set',desc:t.desc,link:appLink('task-'+t.id)});
    }
    created++;
  }
  notifyAdmins(`${CU.name} created ${created} test task${created!==1?'s':''} to verify notifications`,'Task Assigned','Test Tasks');
  updateBadges();
  toast(`${created} test task${created!==1?'s':''} created — ${created!==1?'members':'the member'} notified ✓`,'ok');
  if(page==='alltasks'||page==='dash')nav(page,document.querySelector('.ni.on'));
};

window.saveMember=async()=>{
  const name=document.getElementById('mf-name').value.trim();if(!name){toast('Name required','bad');return;}
  // Build permOverrides from the 4 grant/deny/inherit selects — only
  // explicit choices are stored; "inherit" (empty value) means no key at
  // all, so the employment type default applies with nothing to clean up.
  const permOverrides={};
  ['projects','services','library','docs','archive','comments','reminders'].forEach(perm=>{
    const v=document.getElementById('mf-perm-'+perm)?.value;
    if(v==='grant')permOverrides[perm]=true;
    else if(v==='deny')permOverrides[perm]=false;
  });
  const autoRemindersActive=document.getElementById('mf-auto-rem')?document.getElementById('mf-auto-rem').checked:true;
  const pwField=document.getElementById('mf-password')?.value?.trim()||'';
  if(_editId){
    const m=DB.team.find(x=>x.id===_editId);if(!m)return;
    m.name=name; m.role=document.getElementById('mf-role').value; m.dept=document.getElementById('mf-dept').value;
    m.access=document.getElementById('mf-access').value; m.email=document.getElementById('mf-email').value;
    m.memberType=document.getElementById('mf-mtype')?.value||m.memberType||'';
    m.telegram=document.getElementById('mf-telegram').value.trim();
    m.permOverrides=permOverrides;
    m.autoRemindersActive=autoRemindersActive;
    m.av=mkAv(name);
    if(document.getElementById('mf-username')?.value) m.username=document.getElementById('mf-username').value.trim().toLowerCase();
    logAction('Member Updated',`${esc(CU.name)} updated "${name}"`,'Info',name,'');
    // pwField blank = leave the existing password untouched (upsert_member
    // treats a null/blank password as "don't change it" server-side).
    await nMemberUpd(m,pwField);
    CM('m-mbr'); toast('Member updated ✓'+(pwField?' — password changed':''),'ok');
    if(page==='team')nav('team',document.querySelector('.ni.on'));
  } else {
    const colors=['#4f46e5','#7c3aed','#0369a1','#047857','#b45309','#be185d','#dc2626'];
    const m={id:'u'+gid(),name,role:document.getElementById('mf-role').value,dept:document.getElementById('mf-dept').value,access:document.getElementById('mf-access').value,memberType:document.getElementById('mf-mtype')?.value||'',status:'Active',email:document.getElementById('mf-email').value,telegram:document.getElementById('mf-telegram').value.trim(),permOverrides,autoRemindersActive,av:mkAv(name),color:colors[Math.floor(Math.random()*colors.length)],notes:'',password:pwField||undefined};
    DB.team.push(m);
    logAction('Member Added',`${esc(CU.name)} added "${name}"`,'Success',name,'');
    const r=await nMember(m,m.id); if(r?.url)NID[m.id]=r.url;
    delete m.password; // never keep a password value sitting in the client-side cache
    CM('m-mbr');
    if(r?.generated_password){
      // No password was typed, so the server generated a random temp one —
      // this is the only moment it's ever visible; show it once so the
      // admin can hand it to the new member.
      alert(`${name} was added.\n\nTemporary password: ${r.generated_password}\n\nShare this with them securely — it won't be shown again. They should change it after first login.`);
    } else {
      toast(`${name} added ✓`,'ok');
    }
    if(page==='team')nav('team',document.querySelector('.ni.on'));
  }
};


function openSvcModal(id){
  _editId=id;
  const s=id?DB.services.find(x=>x.id===id):null;
  document.getElementById('m-svc-t').textContent=s?'Edit Service':'Add Service';
  document.getElementById('sf-btn').textContent=s?'Save Changes':'Add Service';
  document.getElementById('sf-name').value=s?.name||'';
  if(document.getElementById('sf-status'))document.getElementById('sf-status').value=s?.status||'Live';
  if(document.getElementById('sf-type'))document.getElementById('sf-type').value=s?.service_type||'Digital';
  if(document.getElementById('sf-cat'))document.getElementById('sf-cat').value=s?.cat||'Content';
  if(document.getElementById('sf-desc'))document.getElementById('sf-desc').value=s?.desc||'';
  if(document.getElementById('sf-about'))document.getElementById('sf-about').value=s?.about||'';
  if(document.getElementById('sf-benefits'))document.getElementById('sf-benefits').value=s?.benefits||'';
  if(document.getElementById('sf-link'))document.getElementById('sf-link').value=s?.link||'';
  if(document.getElementById('sf-location'))document.getElementById('sf-location').value=s?.location_name||'';
  // Populate operator dropdown
  const opEl=document.getElementById('sf-operator');
  if(opEl){
    opEl.innerHTML='<option value="">None</option>'+DB.operators.map(o=>`<option value="${esc(o.name)}" ${s?.operator_name===o.name?'selected':''}>${esc(o.name)}</option>`).join('');
    if(s?.operator_name)opEl.value=s.operator_name;
  }
  // Populate company dropdown
  const coEl=document.getElementById('sf-owned');
  if(coEl){
    coEl.innerHTML='<option value="">None</option>'+[...DB.companies,...DB.operators].map(c=>`<option value="${esc(c.name)}" ${s?.owned_by===c.name?'selected':''}>${esc(c.name)}</option>`).join('');
    if(s?.owned_by)coEl.value=s.owned_by;
  }
  OM('m-svc');
}
window.saveService=async()=>{
  const name=document.getElementById('sf-name').value.trim();if(!name){toast('Name required','bad');return;}
  if(_editId){
    const s=DB.services.find(x=>x.id===_editId);if(!s)return;
    s.name=name;
    s.cat=document.getElementById('sf-cat')?.value||'';
    s.status=document.getElementById('sf-status').value;
    s.service_type=document.getElementById('sf-type')?.value||'Digital';
    s.desc=document.getElementById('sf-desc').value;
    s.about=document.getElementById('sf-about')?.value||'';
    s.benefits=document.getElementById('sf-benefits')?.value||'';
    s.operator_name=document.getElementById('sf-operator')?.value||'';
    s.owned_by=document.getElementById('sf-owned')?.value||'';
    s.location_name=document.getElementById('sf-location')?.value||'';
    s.link=document.getElementById('sf-link')?.value||'';
    await nServiceUpd(s); CM('m-svc'); toast('Service updated ✓','ok');
    if(page==='services')nav('services',document.querySelector('.ni.on'));
  } else {
        const s={
      id:'s'+gid(), name,
      cat: document.getElementById('sf-cat')?.value||'',
      status: document.getElementById('sf-status').value,
      service_type: document.getElementById('sf-type')?.value||'Digital',
      desc: document.getElementById('sf-desc').value,
      about: document.getElementById('sf-about')?.value||'',
      benefits: document.getElementById('sf-benefits')?.value||'',
      operator_name: document.getElementById('sf-operator')?.value||'',
      owned_by: document.getElementById('sf-owned')?.value||'',
      location_name: document.getElementById('sf-location')?.value||'',
      link: document.getElementById('sf-link')?.value||'',
      future_plans: [],
    };
    DB.services.push(s);
    const r=await nService(s,s.id); if(r?.url)NID[s.id]=r.url;
    CM('m-svc'); toast(`${name} added ✓`,'ok');
    if(page==='services')nav('services',document.querySelector('.ni.on'));
  }
};

window.saveProject=async()=>{
  const name=document.getElementById('pf-name')?.value?.trim();
  if(!name){toast('Project name required','bad');return;}
  const ownedEl=document.getElementById('pf-owned');
  const ownedName=ownedEl?.options[ownedEl.selectedIndex]?.text||'';
  const memberIds=Array.from(document.getElementById('pf-members')?.selectedOptions||[]).map(o=>o.value);
  const data={
    name, status:document.getElementById('pf-status').value,
    locationName:document.getElementById('pf-location').value,
    field_of_work:document.getElementById('pf-field')?.value||'',
    ownedBy:ownedName,
    company_owner:ownedName,
    ownerCompanyId:document.getElementById('pf-owned').value||null,
    startedAt:document.getElementById('pf-started').value||null,
    targetDate:document.getElementById('pf-target').value||null,
    member_ids:memberIds,
    link:document.getElementById('pf-link').value||'',
    desc:document.getElementById('pf-desc').value||'',
    about:document.getElementById('pf-about')?.value||'',
    benefits:document.getElementById('pf-benefits')?.value||'',
  };
  if(_editId){
    const pr=DB.projects.find(x=>x.id===_editId);if(!pr)return;
    Object.assign(pr,data);
    await nProjectUpd(pr);CM('m-proj');toast('Project updated ✓','ok');
  } else {
    const pr={id:'p'+gid(),...data,completedAt:null,future_plans:[]};
    DB.projects.push(pr);
    await nProject(pr,pr.id);CM('m-proj');toast('Project created ✓','ok');
  }
  nav(page,document.querySelector('.ni.on'));
};

function openProjectModal(id){
  _editId=id; const pr=id?DB.projects.find(x=>x.id===id):null;
  document.getElementById('m-proj-t').textContent=pr?'Edit Project':'New Project';
  document.getElementById('pf-btn').textContent=pr?'Save Changes':'Save Project';
  document.getElementById('pf-name').value=pr?.name||'';
  document.getElementById('pf-status').value=pr?.status||'Planning';
  document.getElementById('pf-location').value=pr?.locationName||'';
  document.getElementById('pf-started').value=pr?.startedAt||'';
  document.getElementById('pf-target').value=pr?.targetDate||'';
  document.getElementById('pf-link').value=pr?.link||'';
  document.getElementById('pf-desc').value=pr?.desc||'';
  if(document.getElementById('pf-about'))document.getElementById('pf-about').value=pr?.about||'';
  if(document.getElementById('pf-benefits'))document.getElementById('pf-benefits').value=pr?.benefits||'';
  if(document.getElementById('pf-field')) document.getElementById('pf-field').value=pr?.field_of_work||'';
  // Populate members multi-select
  const pMbrEl=document.getElementById('pf-members');
  if(pMbrEl){
    pMbrEl.innerHTML=DB.team.map(m=>`<option value="${m.id}" ${(pr?.member_ids||[]).includes(m.id)?'selected':''}>${esc(m.name)} — ${m.role}</option>`).join('');
  }
  document.getElementById('pf-owned').innerHTML='<option value="">None</option>'+
    [...DB.companies,...DB.operators].map(c=>`<option value="${c.id}" ${pr?.ownerCompanyId===c.id?'selected':''}>${esc(c.name)}</option>`).join('');
  if(pr?.ownerCompanyId) document.getElementById('pf-owned').value=pr.ownerCompanyId;
  // Apply saved project lists
  try{
    const saved=JSON.parse(localStorage.getItem('vas_dropdown_lists')||'{}');
    const stats=saved.projectStatuses||['Planning','Active','On Hold','Completed','Cancelled'];
    const fields=saved.projectFields||['Engineering','Content','Design','Marketing','Operations','Finance','Research','Other'];
    const stEl=document.getElementById('pf-status');
    const fiEl=document.getElementById('pf-field');
    if(stEl){const cv=stEl.value;stEl.innerHTML=stats.map(s=>`<option ${cv===s?'selected':''}>${s}</option>`).join('');if(stats.includes(cv))stEl.value=cv;}
    if(fiEl){const cv=fiEl.value;fiEl.innerHTML='<option value="">Select…</option>'+fields.map(f=>`<option ${cv===f?'selected':''}>${f}</option>`).join('');if(fields.includes(cv))fiEl.value=cv;}
  }catch(e){}
  OM('m-proj');
}
window.saveOperator=async()=>{
  const name=document.getElementById('of-name').value.trim();if(!name){toast('Name required','bad');return;}
  const data={name,type:'Telecom Operator',country:document.getElementById('of-country').value,status:document.getElementById('of-status').value,contact:document.getElementById('of-contact').value,email:document.getElementById('of-email').value,phone:document.getElementById('of-phone').value,notes:document.getElementById('of-notes').value};
  if(_editId){
    const o=DB.operators.find(x=>x.id===_editId);if(!o)return;
    Object.assign(o,data); await nCompanyUpd(o); CM('m-op'); toast('Operator updated ✓','ok');
    if(page==='operators')nav('operators',document.querySelector('.ni.on'));
  } else {
    const o={id:'o'+gid(),...data};
    DB.operators.push(o);
    const r=await nCompany(o,o.id); if(r?.url)NID[o.id]=r.url;
    CM('m-op'); toast(`${name} added ✓`,'ok');
    if(page==='operators')nav('operators',document.querySelector('.ni.on'));
  }
};

window.saveCompany=async()=>{
  const name=document.getElementById('cf-name').value.trim();if(!name){toast('Name required','bad');return;}
  const data={name,type:document.getElementById('cf-type').value,country:document.getElementById('cf-country').value,contact:document.getElementById('cf-contact').value,email:document.getElementById('cf-email').value,notes:document.getElementById('cf-notes').value};
  if(_editId){
    const c=DB.companies.find(x=>x.id===_editId);if(!c)return;
    Object.assign(c,data); await nCompanyUpd(c); CM('m-co'); toast('Company updated ✓','ok');
    if(page==='companies')nav('companies',document.querySelector('.ni.on'));
  } else {
    const c={id:'c'+gid(),...data};
    DB.companies.push(c);
    const r=await nCompany(c,c.id); if(r?.url)NID[c.id]=r.url;
    CM('m-co'); toast(`${name} added ✓`,'ok');
    if(page==='companies')nav('companies',document.querySelector('.ni.on'));
  }
};

window.saveDoc=async()=>{
  const title=document.getElementById('df-title').value.trim();
  const content=document.getElementById('df-content').value.trim();
  if(!title||!content){toast('Title and content required','bad');return;}
  if(_editId){
    const d=DB.docs.find(x=>x.id===_editId);if(!d)return;
    d.title=title; d.type=document.getElementById('df-type').value; d.status=document.getElementById('df-status').value; d.content=content;
    logAction('Document Updated',`${esc(CU.name)} updated doc "${title}"`,'Info',title,'');
    await nDocUpd(d); CM('m-doc'); toast('Document updated ✓','ok');
    window._docsAll=[...DB.docs];
    if(page==='docs')nav('docs',document.querySelector('.ni.on'));
  } else {
    const doc={id:'d'+gid(),title,type:document.getElementById('df-type').value,status:document.getElementById('df-status').value,author:CU.id||'',fromTask:null,content,at:now()};
    DB.docs.unshift(doc); window._docsAll=[...DB.docs];
    logAction('Document Created',`${esc(CU.name)} created doc "${title}"`,'Success',title,'');
    const r=await nDoc(doc,doc.id); if(r?.url)NID[doc.id]=r.url;
    CM('m-doc'); toast('Document saved ✓','ok');
    if(page==='docs')nav('docs',document.querySelector('.ni.on'));
  }
};

window.saveBacklog=async()=>{
  const title=document.getElementById('bf-title').value.trim();if(!title){toast('Title required','bad');return;}
  const b={id:'b'+gid(),title,status:'New Idea',cat:document.getElementById('bf-cat').value,priority:document.getElementById('bf-prio').value,by:CU.name,desc:document.getElementById('bf-desc').value,why:document.getElementById('bf-why').value,notes:'',at:now()};
  DB.backlog.unshift(b);
  logAction('Backlog Submitted',`${esc(CU.name)} submitted idea "${title}"`,'Info',title,'');
  const r=await nBacklog(b,b.id); if(r?.url)NID[b.id]=r.url;
  CM('m-bl'); toast('Idea submitted ✓','ok');
  if(page==='backlog')nav('backlog',document.querySelector('.ni.on'));
};

window.saveTodo=async()=>{
  const title=document.getElementById('todo-title')?.value.trim();
  if(!title){toast('Title required','bad');return;}
  const priority=document.getElementById('todo-prio')?.value||'High';
  const due=document.getElementById('todo-due')?.value||null;
  const notes=document.getElementById('todo-notes')?.value||'';
  const reminder=document.getElementById('todo-reminder')?.value||null;

  if(_editId){
    const td=DB.todos.find(x=>x.id===_editId);if(!td){toast('Todo not found','bad');return;}
    td.title=title; td.priority=priority; td.due=due; td.notes=notes; td.reminder=reminder;
    // If todo has a real Supabase id (not local), update it
    if(td.id&&!td.id.startsWith('td')){
      await nTodoUpd(td);
    } else {
      // Still local — try to save to Supabase now
      const r=await nTodo(td,td.id);
      if(r?.id) td.id=r.id;
    }
    CM('m-todo'); toast('Todo updated ✓','ok');
    updateBadges(); if(page==='todos')nav('todos',document.querySelector('.ni.on'));
  } else {
    const td={
      id:'td'+gid(), title, status:'To Do', priority,
      assignedTo:CU?.name||'', owner:CU?.name||'',
      due, notes, reminder, at:now()
    };
    DB.todos.unshift(td);
    // Try full insert first, fall back to minimal if columns missing
    let r=null;
    try{
      r=await nTodo(td,td.id);
    }catch(e){
      // Fallback: minimal insert without new columns
      showSaving(true);
      r=await sbInsert('todos',{title:td.title,status:'To Do',priority:td.priority,assigned_to_name:td.assignedTo,due:td.due||null,notes:td.notes||''});
      showSaving(false);
    }
    if(r?.id) td.id=r.id;
    CM('m-todo'); toast('Todo added ✓','ok'); updateBadges();
    if(page==='todos')nav('todos',document.querySelector('.ni.on'));
  }
};

// ══════════════════════════════════════════════════════
// NOTIFICATIONS — clickable with action callbacks
// ══════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════
// NOTIFICATIONS — Notion-backed, visible to all users
// ══════════════════════════════════════════════════════
// meta: optional {taskId, meetingId, hrComId, annId} — whichever is set
// determines where clicking this notification (in the bell drawer) takes
// the user. Falls back to the old taskTitle-match behaviour when no meta
// is given, so existing call sites keep working unchanged.
function _linkFromMeta(meta){
  if(!meta) return {type:null,id:null};
  if(meta.taskId)    return {type:'task',id:meta.taskId};
  if(meta.meetingId) return {type:'meeting',id:meta.meetingId};
  if(meta.hrComId)   return {type:'hrcom',id:meta.hrComId};
  if(meta.annId)     return {type:'announcement',id:meta.annId};
  if(meta.testSessionId) return {type:'testsession',id:meta.testSessionId};
  return {type:null,id:null};
}

async function sendNotif(toName, text, type='Mention', taskTitle='', adminsOnly=false, meta={}){
  if(!toName&&!adminsOnly)return;
  const {type:linkType,id:linkId}=_linkFromMeta(meta);
  const n={
    id:gid(),nid:null,
    to:toName||'',from:CU?.name||'',
    text,type,taskTitle,
    linkType,linkId,
    adminsOnly,readBy:[],time:now()
  };
  notifs.unshift(n);notifs=notifs.slice(0,60);
  // Show immediately for current user if relevant
  if(sameName(n.to,CU?.name)||(n.adminsOnly&&isAdmin()))renderNotifs();
  updateBadges();
  // Persist to Supabase async (non-blocking). link_type/link_id use the
  // silent writer since those columns are an additive migration — older
  // deployments that haven't run it yet degrade to no-link (not an error
  // toast) instead of failing every single notification.
  sbInsertSilent('notifications',{to_name:toName||'',from_name:CU?.name||'',message:text,type,task_title:taskTitle||'',admins_only:adminsOnly,read_by:[],link_type:linkType,link_id:linkId}).then(r=>{if(r?.id)n.id=r.id;}).catch(()=>{});
  // Also always keep in localStorage as fast cache
  localStorage.setItem('v8_notifs_local',JSON.stringify(notifs.slice(0,30)));
}

// Send to all admins
function notifyAdmins(text, type='Mention', taskTitle='', meta={}){
  // Store as admins-only notification
  sendNotif('', text, type, taskTitle, true, meta);
}

// Send to both assignee and all admins
function notifyTaskEvent(task, text, type){
  const meta={taskId:task?.id};
  const ass=DB.team.find(m=>m.id===task.assignedTo);
  const rev=DB.team.find(m=>m.id===task.reviewer);
  if(ass&&!sameName(ass.name,CU?.name)) sendNotif(ass.name, text, type, task.title, false, meta);
  if(rev&&!sameName(rev.name,CU?.name)&&!sameName(rev.name,ass?.name)) sendNotif(rev.name, text, type, task.title, false, meta);
  // Always notify admins (as an admin-only broadcast)
  sendNotif('', text, type, task.title, true, meta);
}

// Per-type color/icon/short-label so the notification drawer card shows
// the event category at a glance, not just the raw text. Falls back to a
// neutral gray bell for any type not in this map (new/legacy types still
// render fine, just unstyled).
const NOTIF_TYPE_META={
  'Task Assigned':{c:'#2563eb',i:'📬',l:'Assigned'},
  'Task Started':{c:'#2563eb',i:'▶️',l:'Started'},
  'Task Submitted':{c:'#7c3aed',i:'📤',l:'Submitted'},
  'Task Updated':{c:'#2563eb',i:'✏️',l:'Updated'},
  'Status Changed':{c:'#2563eb',i:'🔄',l:'Status Changed'},
  'Re-Estimate':{c:'#2563eb',i:'⏱',l:'Re-Estimate'},
  'Review Needed':{c:'#7c3aed',i:'🔍',l:'Review Needed'},
  'Task Approved':{c:'#15803d',i:'✅',l:'Approved'},
  'Task Rejected':{c:'#dc2626',i:'🔴',l:'Rejected'},
  'Task Deleted':{c:'#dc2626',i:'🗑️',l:'Deleted'},
  'Reminder':{c:'#ea580c',i:'⏰',l:'Reminder'},
  'Mention':{c:'#7c3aed',i:'💬',l:'Mention'},
  'Comment':{c:'#7c3aed',i:'💬',l:'Comment'},
  'Help Request':{c:'#0891b2',i:'🤝',l:'Help Request'},
  'Help Accepted':{c:'#15803d',i:'✅',l:'Help Accepted'},
  'Meeting Created':{c:'#0891b2',i:'📅',l:'Meeting'},
  'Meeting Started':{c:'#0891b2',i:'📅',l:'Meeting Started'},
  'Meeting Ended':{c:'#0891b2',i:'📅',l:'Meeting Ended'},
  'Meeting Cancelled':{c:'#dc2626',i:'📅',l:'Cancelled'},
  'Meeting Rescheduled':{c:'#ea580c',i:'📅',l:'Rescheduled'},
  'Service Test Completed':{c:'#0891b2',i:'🧪',l:'Service Test'},
  'Normal Announcement':{c:'#2563eb',i:'📢',l:'Announcement'},
  'Important Announcement':{c:'#ea580c',i:'📢',l:'Important'},
  'Urgent Announcement':{c:'#dc2626',i:'📢',l:'Urgent'},
  'HR Message':{c:'#db2777',i:'💬',l:'HR'},
  'HR Reply':{c:'#db2777',i:'💬',l:'HR Reply'},
  'HR Update':{c:'#db2777',i:'💬',l:'HR Update'},
  'Library Request':{c:'#64748b',i:'📚',l:'Library'},
  'Library Access':{c:'#64748b',i:'📚',l:'Library'},
};
function notifTypeMeta(type){ return NOTIF_TYPE_META[type]||{c:'#64748b',i:'🔔',l:type||'Notification'}; }

function renderNotifs(){
  const list=document.getElementById('nd-list');if(!list)return;
  const mine=notifs.filter(n=>{
    if(sameName(n.to,CU?.name))return true;
    if(n.adminsOnly&&isAdmin())return true;
    return false;
  });
  if(!mine.length){list.innerHTML='<div style="padding:16px;text-align:center;font-size:12px;color:var(--tx3)">All caught up! ✓</div>';updateBadges();return;}
  list.innerHTML=mine.slice(0,12).map(n=>{
    const isRead=n.readBy.some(x=>sameName(x,CU?.name));
    const meta=notifTypeMeta(n.type);
    // The member this notification concerns — whoever performed the
    // triggering action (assigner, approver, commenter, etc). Shown as
    // an avatar chip so it's identifiable at a glance, same as every
    // other member reference in the app, rather than buried in the text.
    const actor=n.from?DB.team.find(m=>sameName(m.name,n.from)):null;
    return`<div class="ndi ${isRead?'':'unr'}" onclick="clickNotif('${n.id}')">
      <div class="nd-d ${isRead?'r':''}"></div>
      <span style="width:26px;height:26px;border-radius:50%;background:${actor?actor.color:'#94a3b8'};display:inline-flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;color:#fff;flex-shrink:0" title="${n.from||'System'}">${actor?actor.av:'⚙'}</span>
      <div style="flex:1;min-width:0">
        <span style="display:inline-block;font-size:9px;font-weight:800;color:${meta.c};background:${meta.c}18;border:1px solid ${meta.c}33;padding:1px 7px;border-radius:20px;margin-bottom:3px">${meta.i} ${meta.l}</span>
        <div class="nd-txt">${esc(n.text)}</div>
        ${n.taskTitle?`<div style="font-size:10px;color:var(--ac);margin-top:1px;font-weight:500">${n.taskTitle}</div>`:''}
        <div class="nd-m">${n.from?`${n.from} · `:''}${fr(n.time)}</div>
      </div>
    </div>`;
  }).join('');
  updateBadges();
}

window.clickNotif=async(id)=>{
  const n=notifs.find(no=>no.id===id);if(!n)return;
  if(!n.readBy.some(x=>sameName(x,CU?.name))){
    n.readBy.push(CU.name);
    localStorage.setItem('v8_notifs_local',JSON.stringify(notifs.slice(0,30)));
    // Update read_by in Supabase async (silent — same reasoning as the
    // insert: never surface an error toast for background sync)
    if(n.id&&!n.id.startsWith('n')){
      sbUpdateSilent('notifications', n.id, {read_by: n.readBy}).catch(()=>{});
    }
    renderNotifs();
  }
  closeND();
  // Route to whatever this notification is actually about. Prefer the
  // explicit link (works for meetings/HR/announcements, and for tasks
  // even when multiple tasks share a title); fall back to the legacy
  // title-match for older notifications sent before this existed.
  const lt=n.linkType||n.link_type, lid=n.linkId||n.link_id;
  if(lt==='task'&&lid){
    // Fetch the current row before opening rather than trusting whatever
    // is already in local DB.tasks — otherwise a submit or a new comment
    // that happened elsewhere silently isn't there until a manual refresh.
    if(typeof fetchAndUpsertTask==='function') await fetchAndUpsertTask(lid);
    const openIt=()=>{ if(DB.tasks.find(tk=>tk.id===lid)) openTask(lid); else toast('Task not found — it may have been deleted','bad'); };
    if(page!=='alltasks'&&page!=='mytasks'){ navTo('alltasks'); setTimeout(openIt,150); }
    else openIt();
    return;
  }
  if(lt==='meeting'&&lid){
    if(typeof fetchAndUpsertMeeting==='function') await fetchAndUpsertMeeting(lid);
    navTo('meetings');
    setTimeout(()=>{ if(typeof openMeetingDetail==='function') openMeetingDetail(lid); },150);
    return;
  }
  if(lt==='testsession'&&lid){
    if(typeof fetchAndUpsertTestSession==='function') await fetchAndUpsertTestSession(lid);
    navTo('svctest');
    setTimeout(()=>{ if(typeof openServiceList==='function') openServiceList(lid); },150);
    return;
  }
  if(lt==='hrcom'&&lid){ navTo('hrcoms'); return; }
  if(lt==='announcement'&&lid){ navTo('announcements'); return; }
  // Legacy fallback — match by task title (old notifications only)
  if(n.taskTitle){
    const t=DB.tasks.find(tk=>tk.title===n.taskTitle);
    if(t){
      if(page!=='alltasks'&&page!=='mytasks'){ navTo('alltasks'); setTimeout(()=>openTask(t.id),150); }
      else openTask(t.id);
    }
  }
};

window.markAllRead=()=>{
  notifs.forEach(n=>{if(!n.readBy.includes(CU?.name))n.readBy.push(CU.name);});
  localStorage.setItem('v8_notifs_local',JSON.stringify(notifs.slice(0,30)));
  renderNotifs();
};
